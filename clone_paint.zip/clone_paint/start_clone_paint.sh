#!/bin/bash
cd "$(dirname "$0")"
python clone_paint.py "$@"
