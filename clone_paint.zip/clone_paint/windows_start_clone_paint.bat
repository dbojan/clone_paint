@echo off
cd /d "%~dp0"
python clone_paint.py %*
