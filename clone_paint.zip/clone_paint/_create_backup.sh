#!/bin/bash

dt="backup/$(date +%Y%m%d-%H%M%S)"
mkdir -p "$dt"
cp -r *.* "$dt/"


read -p "done"
