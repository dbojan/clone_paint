# Clone Paint — Specification

**Version:** 2026-05-31-1  
**Technology:** Python 3, PyQt5, optional Pillow  
**Entry point:** `python3 clone_paint.py [imagefile]`

---

## Overview

Clone Paint is a single-file raster image editor with a familiar MS-Paint-style interface. It features a ribbon toolbar, an ARGB32 canvas, a full drawing toolset, image adjustment filters, and directory-based image navigation. No `.ui` file or build step is required.

---

## Architecture

| Component | Class | Responsibility |
|-----------|-------|----------------|
| Canvas | `Canvas(QWidget)` | Image storage, all drawing, undo/redo, file I/O |
| Main Window | `MainWindow(QMainWindow)` | Ribbon, menus, statusbar, keyboard handling |
| Ribbon | `RibbonGroup`, inline builders | Toolbar panels (Home, View, Image, etc.) |
| Thumbnail Window | `ThumbnailWindow` | Floating live preview of the current canvas |
| File Thumbnails | `FileThumbnailsWindow` | Grid browser of all images in the current folder |
| Color Display | `ColorDisplay` | FG/BG color swatch widget |
| Swatch / CustomSwatch | `Swatch`, `CustomSwatch` | Palette color buttons |

---

## Canvas (`Canvas`)

### Image Model

- Internal format: `QImage.Format_ARGB32`
- Default new-image size: 400 × 400 px
- Separate overlay `QImage` (same size, transparent) for rubber-band previews
- Zoom range: 0.1 × – 16.0 × (displayed via `set_zoom`)
- Source bit-depth is captured on file load and preserved for display in Properties

### Signals

| Signal | Args | Fired when |
|--------|------|------------|
| `color_changed` | `QColor, bool` | FG or BG color changes |
| `size_changed` | `int, int` | Canvas dimensions change |
| `cursor_moved` | `int, int` | Mouse moves over canvas (image coords) |
| `modified_changed` | `bool` | Dirty flag changes |
| `pixel_picked` | `int, int, int` | Shift+click reads a pixel (R, G, B) |
| `image_changed` | — | Any pixel modification |
| `tool_changed` | `str` | Active tool changes |

### Undo / Redo

- Stack depth: 30 states (`MAX_UNDO`)
- Full `QImage` copy pushed before every destructive operation
- Both stacks cleared on file open/new

### File I/O

**Open** (`open_file(path)`):
- Formats: PNG, JPEG, BMP, GIF, TIFF, JPEG XL (`.jxl`)
- JXL: tries Qt plugin first; falls back to `pillow-jxl-plugin`
- Reads source bit-depth before converting to ARGB32
- PNG: reads IHDR `bit_depth` byte directly from file header

**Save** (`save_file(path)`):
- PNG: quality 0 (max compression) if `_max_png_compression` is set, else Qt default
- JPEG: quality 90
- JXL: Qt plugin → `pillow-jxl-plugin` fallback with descriptive error on missing deps
- If a floating selection exists, it is composited onto a copy before saving (canvas state unchanged)

**Auto-save** (`auto_save()`): saves in place for PNG/BMP only when `_auto_save_lossless` is enabled.

---

## Tools

### Drawing Tools

| Tool key | Description |
|----------|-------------|
| `pencil` | 1-pixel aliased freehand |
| `brush` | Freehand with configurable brush type, shape, and hardness |
| `eraser` | Freehand erase; respects transparency toggle |
| `fill` | Flood-fill (4-connected) with FG or BG color |
| `picker` | Sample pixel color into FG (LMB) or BG (RMB) |
| `text` | Click-to-place text via `QInputDialog`; Arial 14 pt |
| `magnifier` | LMB zoom in ×2, RMB zoom out ÷2 |
| `clone` | Clone Stamp — samples from a source point and paints cloned pixels elsewhere |

#### Clone Stamp (`clone`)

**Setting the anchor:** Ctrl+click anywhere on the canvas to anchor the sample origin (`_clone_src`). A crosshair cursor indicates no anchor is set yet; once set, the cursor changes to a stamp icon.

**Brush size:** the clone stamp uses `_pen_width` (the shared brush size) and `_brush_shape` (`circle` | `square`) — the same size control as all other drawing tools.

**Painting:** LMB drag paints pixels copied from the source region. On the first mouse-press of each stroke, the offset between the brush position and `_clone_src` is recorded as `_clone_offset`. As the brush moves, pixels are read from `(brush_pos + _clone_offset)` and written at `brush_pos`.

**Aligned mode** (default `True`): the source point advances in sync with the brush during a stroke and retains that advance between strokes.

**Non-aligned mode**: the source resets to `_clone_src` at the start of every new stroke.

**Edge clamping:** source pixels outside the image bounds are clamped to the nearest edge pixel.

**Live anchor preview (paintEvent):** while the clone tool is active and an anchor is set, two overlays are drawn on top of the canvas in screen space:
- A black crosshair + circle at the fixed anchor position (`_clone_src`)
- A blue crosshair at the moving sample point (`_clone_mouse + _clone_offset`), connected to the anchor by a blue dashed line — this tracks the cursor in real time so the user can see exactly where pixels will be sampled from before painting

**Canvas state fields added:**

| Field | Type | Purpose |
|-------|------|---------|
| `_clone_src` | `QPoint \| None` | Anchor origin (image coords) |
| `_clone_offset` | `QPoint` | Offset from brush to source at stroke start |
| `_clone_aligned` | `bool` | Aligned (True) vs non-aligned (False) mode |
| `_clone_src_set` | `bool` | True after Ctrl+click; cleared on first stroke |
| `_clone_mouse` | `QPoint` | Current cursor position (image coords) for live preview |

**Ribbon:** a "Clone Stamp" button is added to the Tools grid (row 2, col 0), joining `_tool_bg`. Tooltip: `"Clone Stamp — Ctrl+click to set anchor, then drag to paint"`. An "Aligned" checkbox appears below the grid inside the Tools group, wired to `_clone_aligned`.

### Selection Tools

| Tool key | Description |
|----------|-------------|
| `selectrect` | Rectangular marquee; drag to move as floating selection |
| `select` | Freehand (lasso) marquee |

Selection operations: Cut, Copy, Paste, Delete, Select All, Crop to Selection.  
Paste expands canvas if the clipboard image is larger.  
A *floating selection* can be dragged and resized (8 handles: `tl tc tr ml mr bl bc br`) before being committed.

### Shape Tools

Shapes are rendered on the overlay and committed on mouse-release.  
Outline and fill are independently controlled (no outline / no fill / solid color).

**Basic shapes:** Line, Curve (quadratic Bézier, 2-click), Oval, Rectangle, Rounded Rectangle  
**Polygon:** Click-to-add vertices; right-click or close near start to finish  
**Geometric:** Triangle, Right Triangle, Diamond, Pentagon, Hexagon  
**Arrows:** Right, Left, Up, Down  
**Stars:** 4-point, 5-point, 6-point  
**Callouts:** Rounded Rectangular, Oval, Cloud  
**Special:** Heart (cubic Bézier path), Lightning  

### Brush Types

Normal, Calligraphy 1, Calligraphy 2, Airbrush, Oil Brush, Crayon, Marker, Natural Pencil, Watercolor

Brush parameters: shape (`circle` | `square`), hardness (1–100 %), width (1–500 px).

---

## Image Adjustments / Filters

All operations push an undo state first.  
Pillow is used when available; a pure-Qt pixel-loop fallback is provided for every operation.

| Operation | Method | Notes |
|-----------|--------|-------|
| Grayscale | `convert_grayscale()` | Luminosity method (0.299 R + 0.587 G + 0.114 B) |
| Black & White | `convert_black_white(threshold=128)` | Threshold-based |
| Brightness | `adjust_brightness(delta)` | −255 … +255 |
| Gamma | `adjust_gamma(gamma)` | 1.0 = no change; per-channel LUT |
| Contrast | `adjust_contrast(factor)` | 0.0 … 4.0; 1.0 = no change |
| Sharpen | `sharpen()` | Unsharp mask via Pillow |
| Invert | `invert()` | |
| Sepia | `sepia()` | |
| Hue/Saturation | `adjust_hue_saturation(hue, sat)` | |
| Blur | `blur(radius)` | |

---

## Transforms

| Operation | Method | Notes |
|-----------|--------|-------|
| Rotate 90 CW/CCW, 180 | `rotate(deg)` | Operates on floating selection if present |
| Flip horizontal/vertical | `flip(horizontal)` | Operates on floating selection if present |
| Resize | `resize_image(w, h)` | Dialog with aspect-ratio lock |
| Custom rotation | Dialog | Angle (°), antialiasing, background color |
| Crop to selection | `crop_to_selection()` | |
| Canvas resize (drag handles) | 3 handles: right-mid, bottom-mid, corner | Ctrl held at corner = maintain aspect ratio |

---

## Color System

**Palette:** 20 fixed swatches matching exact MS Paint RGB values (2 rows × 10).  
**Custom palette:** 10 user-definable slots (row 3); right-click to set, persisted to INI.  
**FG / BG:** LMB = FG (Color 1), RMB = BG (Color 2).  
**Edit Colors:** opens `QColorDialog`.  

---

## UI Structure

### Ribbon

The application uses a custom ribbon (no `QMenuBar` by default — it is hidden). The ribbon has multiple panels, switchable via tab buttons:

- **Home** — Tools, Brushes, Shapes, Outline/Fill, Size, Colors
- **View** — Zoom (in/out/100%), Show/Hide (rulers, gridlines, statusbar, beep), Display (fullscreen, thumbnail)
- **Image** — Rotate, Flip, Resize, Crop, color-depth adjustments, filters
- **File button** — Dropdown menu replacing File menu

### Status Bar

Shows: cursor position (px), canvas dimensions, zoom level, bit-depth info, file name, modified indicator.

### Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| Ctrl+Z / Ctrl+Y | Undo / Redo |
| Ctrl+S | Save |
| Ctrl+Shift+S | Save As |
| Ctrl+O | Open |
| Ctrl+N | New |
| Ctrl+A | Select All |
| Ctrl+C / X / V | Copy / Cut / Paste |
| Ctrl+T | Open File Thumbnails window |
| Ctrl+scroll | Zoom ±10% |
| Ctrl++ / Ctrl+− | Zoom ×2 / ÷2 |
| Left / Right | Previous / Next image in folder |
| Home / End | First / Last image in folder |
| F2 | Rename file |
| F5 | Reload file |
| F7 / Shift+F7 | Move to folder / Move to temp |
| F8 / Shift+F8 | Copy to folder / Copy to temp |
| Delete | Delete selection (if active) or delete file |
| Esc | Cancel current operation; switch to Rectangular Select |
| Ctrl+click 100% button | Fit image to window |
| Double-click 100% button | Enter zoom level manually |

---

## Directory Navigation

Supported extensions for browsing: `.png .jpg .jpeg .bmp .gif .tif .tiff .jxl`

Files are sorted alphabetically within the directory of the currently open file.  
Navigation wraps around (previous from first → last; next from last → first).  
Unsaved-changes prompt is shown before switching files.

---

## Settings Persistence

Format: INI (`QSettings`).  
Location resolution (in priority order):
1. `clone_paint_settings.ini` alongside the script (portable mode)
2. `%APPDATA%\ClonePaint\clone_paint_settings.ini` (Windows)
3. `~/.config/ClonePaint/clone_paint_settings.ini` (Linux/macOS)

Persisted items: window geometry, window state, zoom, rulers/gridlines/statusbar visibility, beep-on-screenshot, auto-save flags, PNG compression setting, brush/tool selections, custom palette colors.

---

## Icon Loading (`get_icon`)

Icons are loaded from an `icons/` subdirectory next to the script.  
PNG is tried first, then BMP. For BMP files, white pixels (R/G/B > 240) are made transparent. Icons are scaled to the requested size via smooth transformation.

---

## External Dependencies

| Package | Required | Used for |
|---------|----------|---------|
| PyQt5 | **Yes** | All UI, image handling |
| Pillow (`PIL`) | Optional | Higher-quality image filters; fallbacks exist for all uses |
| `pillow-jxl-plugin` | Optional | JPEG XL save/load when Qt JXL plugin is absent |
| `qt-jpegxl-image-plugin` | Optional | Native Qt JPEG XL support (preferred over Pillow path) |

---

## Known / Intentional Limitations

- Text tool uses a fixed Arial 14 pt font with no font-picker dialog.
- Several brush-type and fill-type menu items (Oil, Crayon, Watercolor, etc.) are listed but trigger `lambda: None` — visual placeholders for future implementation.
- Curve tool is quadratic (one control point), not cubic.
- No layer support.
- GIF save does not preserve animation.
