# clone_paint.py — Architecture Spec

## Classes
- `Canvas(QWidget)` — all drawing logic, state, mouse handling (~line 113)
- `MainWindow(QMainWindow)` — toolbar, menus, file management, settings (~line 2000+)

---

## Tool system

### `_tool` values
| value | set by | description |
|---|---|---|
| `'brush'` | `set_tool('brush')` | freehand brush |
| `'pencil'` | `set_tool('pencil')` | 1px pencil |
| `'eraser'` | `set_tool('eraser')` | eraser |
| `'picker'` | `set_tool('picker')` | eyedropper |
| `'text'` | `set_tool('text')` | text insert |
| `'magnifier'` | `set_tool('magnifier')` | zoom |
| `'fill'` | `set_tool('fill')` | flood fill |
| `'selectrect'` | `set_tool('selectrect')` | rectangular selection |
| `'select'` | `set_tool('select')` | free-form selection |
| `'polygon'` | `set_shape('polygon')` | freeform polygon (click-to-add-vertex) |
| `'__shape__'` | `set_shape(s)` for all other shapes | bounding-box shape draw |

### `set_tool(t)` — switches to a non-shape tool
Commits floating selection, finishes any polygon, resets `_curve_phase`, sets `_tool = t`.

### `set_shape(s)` — switches to a shape from the SHAPES panel
- If `s == 'polygon'` → `_tool = 'polygon'`
- All other `s` → `_tool = '__shape__'`, `_shape = s`
- **Never** sets `_tool` to a shape key directly.

---

## SHAPES list (`SHAPES`, line 63)
Each entry: `(icon_name, shape_key, label)`

Shape keys used in `_draw_shape()` dispatch:
`line`, `curve`, `ellipse`, `rect`, `roundrect`, `triangle`, `right_triangle`,
`diamond`, `pentagon`, `hexagon`, `poly8` *(regular octagon — not the polygon tool)*,
`right_arrow`, `left_arrow`, `up_arrow`, `down_arrow`,
`star4`, `star5`, `star6`,
`callout_rect`, `callout_oval`, `callout_cloud`,
`heart`, `lightning`

**`'polygon'` is NOT in `_draw_shape()` — it routes to `_tool='polygon'` instead.**

---

## Polygon tool (`_tool == 'polygon'`)

### State variables
```
_polygon_pts   : list[QPoint]   — vertices in image coords
_polygon_phase : int            — 0=idle, 1=dragging first seg, 2=clicking vertices
_polygon_mouse : QPoint         — current mouse pos for rubber-band preview
```

### Interaction flow
1. **Phase 0 → 1**: LMB press → records start point, `_drawing=True`
2. **Phase 1**: mouse drag → rubber-band preview of first segment
3. **Phase 1 → 2**: LMB release → appends end point, switches to click mode
4. **Phase 2**: each LMB click appends a vertex; rubber-band shows next segment; snap circle drawn around start point when `len >= 3`
5. **Close**: LMB click within `snap_r = max(8, pen_width*3)` px of start → `_finish_polygon()`
6. **Cancel**: RMB at any phase → `_finish_polygon()` (commits what exists if `>= 3` pts)

### `_finish_polygon()`
Requires `>= 3` points. Calls `_push_undo()`, draws with `_mk_pen()` + `_mk_brush()`, resets all polygon state.

---

## Overlay system
- `_overlay` : `QImage` (same size as `_image`, ARGB32, transparent)
- Used for live shape preview while dragging (`__shape__` tool, curve tool)
- `_clear_overlay()` — fills transparent
- `_commit_overlay()` — blits overlay onto `_image`, then clears
- **Polygon tool does NOT use overlay** — preview is painted directly in `paintEvent`

---

## Pen / brush helpers
```python
_mk_pen(color=None)   # respects _shape_outline (0=NoPen), _pen_width, _fg
_mk_brush()           # respects _shape_fill (0=NoBrush, 1=fill with _bg)
```

---

## Undo
```python
_push_undo()   # call BEFORE modifying _image; stores copy; clears redo stack
MAX_UNDO = 30
```
Always call `_push_undo()` before any destructive draw operation.

---

## Key Canvas state
```
_image       : QImage (ARGB32) — the canvas pixels
_fg / _bg    : QColor          — foreground / background color
_pen_width   : int             — current stroke width
_shape_fill  : int             — 0=no fill, 1=fill with _bg
_shape_outline: int            — 0=no outline, 1=outline with _fg
_zoom        : float           — display zoom factor
_drawing     : bool            — true while LMB held for stroke/shape
_start       : QPoint          — drag start in image coords
_shape       : str             — current shape key (only used when _tool=='__shape__')
```

---

## Coordinate helpers
```python
_i(screen_pos)   # screen QPoint → image QPoint  (divides by zoom)
_if(screen_pos)  # screen QPointF → image QPointF
```

## Shape geometry helpers
```python
_norm(x1,y1,x2,y2)         # normalises so x1<x2, y1<y2
_reg_poly(x1,y1,x2,y2, n)  # regular n-gon inscribed in bounding box → QPolygon
_star(x1,y1,x2,y2, n, inner) # n-point star → QPolygon
_arrow(x1,y1,x2,y2, d)     # arrow shape, d='right'|'left'|'up'|'down' → QPolygon
_heart_path(...)            # → QPainterPath
_lightning_poly(...)        # → QPolygon  (matches SVG icon, 6 pts)
_callout_rect_path(...)     # → QPainterPath
_callout_oval_path(...)     # → QPainterPath
_callout_cloud_path(...)    # → QPainterPath  (quadratic bezier, matches SVG icon)
```

---

## Floating selection — extended (shapes + resize)

### Shapes become floating after draw
When `_tool == '__shape__'` and mouse is released, the shape is rendered into a
transparent `QImage` and placed as a floating selection (instead of committing
directly). User can then move or resize it; clicking outside commits it.

### 8 resize handles on floating selection
```
_floating_resize          : bool    — currently resizing
_floating_resize_handle   : str     — 'tl'|'tc'|'tr'|'ml'|'mr'|'bl'|'bc'|'br'
_floating_resize_start_pos: QPoint  — globalPos at drag start
_floating_resize_start_rect: QRect  — _sel_rect at drag start
```
Helpers:
```python
_floating_handles()              # → dict[name, (screen_x, screen_y)]
_floating_handle_at(screen_pos)  # → handle name or None
_floating_cursor_for_handle(h)   # → Qt cursor shape
```
On release, `_floating` is rescaled to new `_sel_rect` size via `.scaled()`.

### _commit_floating now calls _push_undo before drawing to _image
