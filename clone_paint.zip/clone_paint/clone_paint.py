"""
Clone Paint — PyQt5 paint with a familiar interface
Single-file, no .ui dependency.
Run:  python3 clone_paint.py [imagefile]
2026-06-02-1
"""

import sys, os, math, json, random
from pathlib import Path

from PyQt5.QtCore	import (Qt, QPoint, QRect, QSize, QSettings, QTimer,
							  pyqtSignal, QUrl, QPointF)
from PyQt5.QtGui	 import (QPixmap, QImage, QPainter, QPen, QBrush, QColor,
							  QPolygon, QFont, QIcon, QTransform, QPainterPath,
							  QCursor, QKeySequence, QPolygonF)
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, QLabel,
							  QScrollArea, QToolBar, QAction, QActionGroup,
							  QToolButton, QMenu, QMenuBar, QStatusBar,
							  QFileDialog, QColorDialog, QInputDialog,
							  QMessageBox, QSizePolicy, QHBoxLayout,
							  QVBoxLayout, QGridLayout, QFrame, QCheckBox,
							  QSlider, QComboBox, QPushButton, QButtonGroup,
							  QDialog, QGroupBox, QSpinBox, QDoubleSpinBox, QStackedWidget)

# ─── Icon directory ────────────────────────────────────────────────────────────
ICON_DIR = Path(__file__).parent / 'icons'

def get_icon(name, size=24):
	# Try PNG first, then BMP
	for ext in ('png', 'bmp'):
		path = ICON_DIR / f'{name}.{ext}'
		if path.exists():
			img = QImage(str(path))
			if img.isNull():
				continue
			img = img.convertToFormat(QImage.Format_ARGB32)
			if ext == 'bmp':
				# Make white pixels transparent for BMP
				for y in range(img.height()):
					for x in range(img.width()):
						c = img.pixel(x, y)
						r, g, b = (c >> 16) & 0xff, (c >> 8) & 0xff, c & 0xff
						if r > 240 and g > 240 and b > 240:
							img.setPixel(x, y, 0)
			px = QPixmap.fromImage(img)
			if size != 24:
				px = px.scaled(size, size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
			return QIcon(px)
	return QIcon()

# ─── Colour palette ────────────────────────────────────────────────────────────
PALETTE = [
	# Row 1 — exact MS Paint top row RGB values
	'#000000','#7f7f7f','#880015','#ed1c24','#ff7f27','#fff200','#22b14c','#00a2e8','#3f48cc','#a349a4',
	# Row 2 — exact MS Paint bottom row RGB values
	'#ffffff','#c3c3c3','#b97a57','#ffaec9','#ffc90e','#efe4b0','#b5e61d','#99d9ea','#7092be','#c8bfe7',
]
DEFAULT_PALETTE = list(PALETTE)
CUSTOM_PALETTE = [''] * 10  # 3rd row empty slots

# ─── Shapes ────────────────────────────────────────────────────────────────────
SHAPES = [
	# Row 1
	('icon_line',				'line',		   'Line'),
	('icon_curve',			   'curve',		  'Curve'),
	('icon_oval',				'ellipse',		'Oval'),
	('icon_rectangle',		   'rect',		   'Rectangle'),
	# Row 2
	('icon_rounded_rectangle',   'roundrect',	  'Rounded rectangle'),
	('icon_polygon',			 'polygon',		  'Polygon'),
	('icon_triangle',			'triangle',	   'Triangle'),
	('icon_right_triangle',	  'right_triangle', 'Right triangle'),
	# Row 3
	('icon_diamond',			 'diamond',		'Diamond'),
	('icon_pentagon',			'pentagon',	   'Pentagon'),
	('icon_hexagon',			 'hexagon',		'Hexagon'),
	('icon_right_arrow',		 'right_arrow',	'Right arrow'),
	# Row 4
	('icon_left_arrow',		  'left_arrow',	 'Left arrow'),
	('icon_up_arrow',			'up_arrow',	   'Up arrow'),
	('icon_down_arrow',		  'down_arrow',	 'Down arrow'),
	('icon_four_point_star',	 'star4',		  '4-point star'),
	# Row 5
	('icon_five_point_star',	 'star5',		  '5-point star'),
	('icon_six_point_star',	  'star6',		  '6-point star'),
	('icon_rounded_rectangular_callout','callout_rect',   'Rounded rectangular callout'),
	('icon_oval_callout',		'callout_oval',   'Oval callout'),
	# Row 6
	('icon_cloud_callout',	   'callout_cloud',  'Cloud callout'),
	('icon_heart',			   'heart',		  'Heart'),
	('icon_lightning',		   'lightning',	  'Lightning'),
]

BRUSH_TYPES = [
	('icon_brush',	  'Normal'),
	('icon_calligraphy_brush', 'Calligraphy 1'),
	('icon_calligraphy_brush_2', 'Calligraphy 2'),
	('icon_airbrush',   'Airbrush'),
	('icon_oil_brush',   'Oil Brush'),
	('icon_crayon',	 'Crayon'),
	('icon_marker',	 'Marker'),
	('icon_pencil',	 'Natural Pencil'),
	('icon_watercolor_brush', 'Watercolor'),
]

SETTINGS_ORG = 'ClonePaint'
SETTINGS_APP = 'ClonePaint'

# ════════════════════════════════════════════════════════════════════════════════
#  Canvas
# ════════════════════════════════════════════════════════════════════════════════
class Canvas(QWidget):
	color_changed = pyqtSignal(QColor, bool)
	size_changed  = pyqtSignal(int, int)
	cursor_moved  = pyqtSignal(int, int)
	modified_changed = pyqtSignal(bool)
	pixel_picked  = pyqtSignal(int, int, int)
	image_changed = pyqtSignal()
	tool_changed  = pyqtSignal(str)   # emitted when active tool changes
	MAX_UNDO = 30

	def __init__(self, parent=None):
		super().__init__(parent)
		self.setAcceptDrops(True)
		self.setMouseTracking(True)
		self.setCursor(Qt.CrossCursor)

		self._image   = QImage(400, 400, QImage.Format_ARGB32)
		self._image.fill(Qt.white)
		self._overlay = QImage(400, 400, QImage.Format_ARGB32)
		self._overlay.fill(Qt.transparent)
		self._undo_stack = []
		self._redo_stack = []
		self._zoom   = 1.0
		self._tool   = 'brush'
		self._shape  = 'rect'
		self._brush_type  = 'Normal'
		self._brush_shape = 'circle'   # 'circle' or 'square'
		self._brush_hardness = 100	 # 1–100 %
		self._fg	 = QColor(Qt.black)
		self._bg	 = QColor(Qt.white)
		self._pen_width  = 3
		self._shape_fill = 0
		self._shape_outline = 1
		self._drawing  = False
		self._start	= QPoint()
		self._last	 = QPoint()
		self._last_screen = QPointF()
		self._sel_rect = None
		self._sel_free_pts = []
		self._sel_free_screen = []
		self._floating = None		  # floating selection image (from paste or move)
		self._floating_pos = QPoint()  # top-left of floating selection
		self._floating_drag = False	# currently dragging floating selection
		self._floating_drag_start = QPoint()
		self._floating_resize = False      # currently resizing floating selection
		self._floating_resize_handle = None  # which handle: 'tl','tc','tr','ml','mr','bl','bc','br'
		self._floating_resize_start_pos = QPoint()
		self._floating_resize_start_rect = QRect()
		self._polygon_pts = []
		self._polygon_phase = 0   # 0=idle, 1=dragging first seg, 2=clicking vertices
		self._polygon_mouse = QPoint()  # current mouse pos for rubber-band
		self._curve_phase = 0  # 0=draw line, 1=drag control
		self._curve_start = QPoint()
		self._curve_end   = QPoint()
		self._curve_ctrl  = QPoint()

		self._show_transparency = True
		self._auto_save_lossless = False
		self._max_png_compression = False
		self._pinch_stretch = False
		self._show_rulers	= False
		self._show_gridlines = False
		self._filename = ''
		self._modified = False
		self._source_depth = None   # bit depth as stored in the file (None = new/unsaved)
		# Resize handle state
		self._resizing = False
		self._resize_handle = None
		self._resize_start_pos = QPoint()
		self._resize_start_size = QSize()
		self._resize_preview = None
		self._HANDLE_SIZE = 8
		self._update_size()

	# Properties
	@property
	def zoom(self): return self._zoom
	@property
	def filename(self): return self._filename
	@property
	def modified(self): return self._modified

	def _set_modified(self, v):
		self._modified = v
		self.modified_changed.emit(v)

	def set_tool(self, t):
		self._commit_floating()
		self._finish_polygon()
		self._curve_phase = 0
		self._tool = t
		self._drawing = False
		self._clear_overlay()
		self.update()
		self._update_cursor()
		self.tool_changed.emit(t)

	def _update_cursor(self):
		t = self._tool
		if t == 'eraser':
			sz=max(4,int(self._pen_width*self._zoom))
			pm=QPixmap(sz+2,sz+2); pm.fill(Qt.transparent)
			pp=QPainter(pm); pp.setRenderHint(QPainter.Antialiasing,self._brush_shape=='circle')
			pp.setPen(QPen(Qt.black,1))
			if self._brush_shape=='circle': pp.drawEllipse(1,1,sz-1,sz-1)
			else: pp.drawRect(1,1,sz-1,sz-1)
			pp.end(); self.setCursor(QCursor(pm,sz//2,sz//2))
		elif t in ('pencil', 'brush', '__shape__'):
			self._make_pen_cursor()
		elif t in ('selectrect', 'select'):
			self.setCursor(Qt.CrossCursor)
		elif t == 'picker':   self.setCursor(Qt.PointingHandCursor)
		elif t == 'text':	 self.setCursor(Qt.IBeamCursor)
		elif t == 'magnifier':self.setCursor(Qt.ArrowCursor)
		else:				 self.setCursor(Qt.CrossCursor)

	def _make_pen_cursor(self):
		psz=max(1,self._pen_width); total=16+psz+4
		pm=QPixmap(total,total); pm.fill(Qt.transparent)
		p=QPainter(pm); p.setRenderHint(QPainter.Antialiasing,self._brush_shape=='circle')
		ox=psz//2; oy=psz//2
		arrow=QPolygon([QPoint(ox,oy),QPoint(ox,oy+14),QPoint(ox+4,oy+10),
						QPoint(ox+7,oy+16),QPoint(ox+9,oy+15),QPoint(ox+6,oy+9),QPoint(ox+11,oy+9)])
		p.setPen(QPen(Qt.white,2)); p.setBrush(Qt.NoBrush); p.drawPolygon(arrow)
		p.setPen(QPen(Qt.black,1)); p.setBrush(QBrush(Qt.black)); p.drawPolygon(arrow)
		if self._brush_shape=='circle':
			p.setPen(QPen(Qt.white,1)); p.setBrush(Qt.NoBrush); p.drawEllipse(0,0,psz+1,psz+1)
			p.setPen(Qt.NoPen); p.setBrush(QBrush(QColor(0,0,0,180))); p.drawEllipse(1,1,psz-1,psz-1)
		else:
			p.setPen(QPen(Qt.white,1)); p.setBrush(Qt.NoBrush); p.drawRect(0,0,psz+1,psz+1)
			p.setPen(Qt.NoPen); p.fillRect(1,1,psz,psz,QColor(0,0,0,180))
		p.end(); self.setCursor(QCursor(pm,psz//2,psz//2))

	def set_shape(self, s):
		self._finish_polygon()
		self._curve_phase = 0
		self._shape = s
		if s == 'polygon':
			self._tool = 'polygon'
		else:
			self._tool = '__shape__'
		self._drawing = False
		self._clear_overlay()
		self.update()
		self.setCursor(Qt.CrossCursor)

	def set_fg(self, c): self._fg = c
	def set_bg(self, c): self._bg = c
	def set_pen_width(self, w): self._pen_width = w; self._update_cursor()
	def set_brush_type(self, t): self._brush_type = t
	def set_shape_fill(self, v): self._shape_fill = v
	def set_shape_outline(self, v): self._shape_outline = v
	def set_show_transparency(self, v): self._show_transparency = v; self.update()
	def set_brush_shape(self, shape): self._brush_shape = shape		  # 'circle'|'square'
	def set_brush_hardness(self, h):  self._brush_hardness = max(1, min(100, h))

	# ─── Image processing ─────────────────────────────────────────────────────

	def color_depth_info(self):
		"""Return (max_colors, label) from the file's actual bit depth when known,
		falling back to the Qt in-memory format for new/unsaved images."""
		depth = getattr(self, '_source_depth', None)
		if depth is not None:
			max_c = 2 ** depth
			labels = {
				1:  '1-bit (2 colors)',
				2:  '2-bit (4 colors)',
				4:  '4-bit (16 colors)',
				8:  '8-bit (256 colors)',
				15: '15-bit (32K colors)',
				16: '16-bit (65K colors)',
				24: '24-bit (16M colors)',
				32: '32-bit (16M colors+α)',
			}
			return (max_c, labels.get(depth, f'{depth}-bit ({max_c:,} colors)'))
		# New/unsaved image — Qt format is authoritative
		fmt = self._image.format()
		_fmt_map = {
			QImage.Format_Mono:		   (2,		'1-bit (2 colors)'),
			QImage.Format_MonoLSB:		(2,		'1-bit (2 colors)'),
			QImage.Format_Indexed8:	   (256,	  '8-bit (256 colors)'),
			QImage.Format_Grayscale8:	 (256,	  '8-bit (256 colors)'),
			QImage.Format_Grayscale16:	(65536,	'16-bit (65K colors)'),
			QImage.Format_RGB888:		 (16777216, '24-bit (16M colors)'),
			QImage.Format_ARGB32:		 (16777216, '32-bit (16M colors+α)'),
			QImage.Format_ARGB32_Premultiplied: (16777216, '32-bit (16M colors+α)'),
			QImage.Format_RGBA8888:	   (16777216, '32-bit (16M colors+α)'),
		}
		if fmt in _fmt_map:
			return _fmt_map[fmt]
		d = self._image.depth()
		max_c = min(2 ** d, 16777216)
		return (max_c, f'{d}-bit ({max_c:,} colors)')

	def _emit_changed(self):
		self._set_modified(True)
		self.update()
		self.image_changed.emit()

	# ── helpers ───────────────────────────────────────────────────────────────
	def _to_pil(self):
		"""QImage ARGB32 → PIL RGBA (zero-copy path via buffer)."""
		from PIL import Image as _PIL
		return self._qimage_to_pil(self._image)

	def _from_pil(self, pil_img):
		"""PIL RGBA → QImage ARGB32, written back into self._image."""
		self._image = self._pil_to_qimage(pil_img)

	# ── operations ────────────────────────────────────────────────────────────

	def convert_grayscale(self):
		"""Convert image to grayscale (luminosity method), keeping alpha."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageOps
			pil  = self._to_pil()
			gray = ImageOps.grayscale(pil.convert('RGB')).convert('RGB')
			gray.putalpha(pil.getchannel('A'))
			self._from_pil(gray)
		except Exception:
			w, h = self._image.width(), self._image.height()
			for y in range(h):
				for x in range(w):
					c = QColor(self._image.pixel(x, y))
					lum = int(0.299*c.red() + 0.587*c.green() + 0.114*c.blue())
					self._image.setPixel(x, y, QColor(lum, lum, lum, c.alpha()).rgba())
		self._emit_changed()

	def convert_black_white(self, threshold=128):
		"""Convert image to black & white (threshold-based), keeping alpha."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageOps
			pil  = self._to_pil()
			gray = ImageOps.grayscale(pil.convert('RGB'))
			bw   = gray.point(lambda v: 255 if v >= threshold else 0).convert('RGB')
			bw.putalpha(pil.getchannel('A'))
			self._from_pil(bw)
		except Exception:
			w, h = self._image.width(), self._image.height()
			for y in range(h):
				for x in range(w):
					c = QColor(self._image.pixel(x, y))
					lum = int(0.299*c.red() + 0.587*c.green() + 0.114*c.blue())
					v = 255 if lum >= threshold else 0
					self._image.setPixel(x, y, QColor(v, v, v, c.alpha()).rgba())
		self._emit_changed()

	def adjust_brightness(self, delta):
		"""Shift R/G/B by delta (−255 … +255)."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageEnhance
			pil	= self._to_pil()
			# Map delta (-255…+255) to an enhance factor (0…~2)
			factor = 1.0 + delta / 255.0
			factor = max(0.0, factor)
			rgb	= pil.convert('RGB')
			bright = ImageEnhance.Brightness(rgb).enhance(factor).convert('RGB')
			bright.putalpha(pil.getchannel('A'))
			self._from_pil(bright)
		except Exception:
			w, h = self._image.width(), self._image.height()
			for y in range(h):
				for x in range(w):
					c = QColor(self._image.pixel(x, y))
					r = max(0, min(255, c.red()   + delta))
					g = max(0, min(255, c.green() + delta))
					b = max(0, min(255, c.blue()  + delta))
					self._image.setPixel(x, y, QColor(r, g, b, c.alpha()).rgba())
		self._emit_changed()

	def adjust_gamma(self, gamma):
		"""Apply gamma correction (gamma 1.0 = no change)."""
		if gamma <= 0: return
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageOps
			pil  = self._to_pil()
			rgb  = pil.convert('RGB')
			# PIL gamma via point(): apply 1/gamma curve to each channel
			lut  = [int(255 * pow(i / 255.0, 1.0 / gamma)) for i in range(256)]
			corr = rgb.point(lut * 3).convert('RGB')
			corr.putalpha(pil.getchannel('A'))
			self._from_pil(corr)
		except Exception:
			lut = [int(255 * pow(i / 255.0, 1.0 / gamma)) for i in range(256)]
			w, h = self._image.width(), self._image.height()
			for y in range(h):
				for x in range(w):
					c = QColor(self._image.pixel(x, y))
					self._image.setPixel(x, y,
						QColor(lut[c.red()], lut[c.green()], lut[c.blue()], c.alpha()).rgba())
		self._emit_changed()

	def adjust_contrast(self, factor):
		"""Multiply contrast by factor (0.0 … 4.0, 1.0 = no change)."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageEnhance
			pil	= self._to_pil()
			rgb	= pil.convert('RGB')
			result = ImageEnhance.Contrast(rgb).enhance(factor).convert('RGB')
			result.putalpha(pil.getchannel('A'))
			self._from_pil(result)
		except Exception:
			w, h = self._image.width(), self._image.height()
			for y in range(h):
				for x in range(w):
					c = QColor(self._image.pixel(x, y))
					r = max(0, min(255, int((c.red()   - 128) * factor + 128)))
					g = max(0, min(255, int((c.green() - 128) * factor + 128)))
					b = max(0, min(255, int((c.blue()  - 128) * factor + 128)))
					self._image.setPixel(x, y, QColor(r, g, b, c.alpha()).rgba())
		self._emit_changed()

	def sharpen(self):
		"""Apply unsharp sharpening."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageFilter
			pil	= self._to_pil()
			rgb	= pil.convert('RGB')
			result = rgb.filter(ImageFilter.SHARPEN).convert('RGB')
			result.putalpha(pil.getchannel('A'))
			self._from_pil(result)
		except Exception:
			self._apply_kernel([[0,-1,0],[-1,5,-1],[0,-1,0]])
		self._emit_changed()

	def blur(self):
		"""Apply a box blur."""
		self._push_undo()
		try:
			from PIL import Image as _PIL, ImageFilter
			pil	= self._to_pil()
			rgb	= pil.convert('RGB')
			result = rgb.filter(ImageFilter.BLUR).convert('RGB')
			result.putalpha(pil.getchannel('A'))
			self._from_pil(result)
		except Exception:
			k = 1/9
			self._apply_kernel([[k,k,k],[k,k,k],[k,k,k]])
		self._emit_changed()

	def _apply_kernel(self, kernel):
		"""Pure-Python 3×3 convolution fallback (used only when Pillow is absent)."""
		w, h = self._image.width(), self._image.height()
		src = self._image.copy()
		for y in range(1, h - 1):
			for x in range(1, w - 1):
				r_sum = g_sum = b_sum = 0.0
				for ky in range(-1, 2):
					for kx in range(-1, 2):
						c = QColor(src.pixel(x + kx, y + ky))
						k = kernel[ky + 1][kx + 1]
						r_sum += c.red()   * k
						g_sum += c.green() * k
						b_sum += c.blue()  * k
				orig_a = QColor(src.pixel(x, y)).alpha()
				self._image.setPixel(x, y,
					QColor(max(0, min(255, int(r_sum))),
						   max(0, min(255, int(g_sum))),
						   max(0, min(255, int(b_sum))),
						   orig_a).rgba())

	def reduce_colors(self, target_colors):
		"""Reduce the image to at most target_colors colours using Pillow's C quantizer."""
		target_colors = max(2, min(256, target_colors))
		self._push_undo()
		try:
			from PIL import Image as _PIL
			pil = self._qimage_to_pil(self._image)
			# quantize() works on RGB; handle alpha by splitting it off first
			rgb  = pil.convert('RGB')
			alpha = pil.getchannel('A')
			quant = rgb.quantize(colors=target_colors, method=_PIL.Quantize.MEDIANCUT, dither=0)
			quant = quant.convert('RGB')
			quant.putalpha(alpha)
			self._image = self._pil_to_qimage(quant)
		except Exception:
			# Pillow unavailable or failed — fall back to simple Python quantiser
			self._reduce_colors_fallback(target_colors)
		self._source_depth = (target_colors - 1).bit_length()   # update depth info
		self._emit_changed()

	def _reduce_colors_fallback(self, target_colors):
		"""Pure-Python median-cut fallback (slow, used only when Pillow is absent)."""
		w, h = self._image.width(), self._image.height()
		pixels = []
		for y in range(h):
			for x in range(w):
				c = QColor(self._image.pixel(x, y))
				pixels.append((c.red(), c.green(), c.blue()))
		palette = self._median_cut(pixels, target_colors)
		for y in range(h):
			for x in range(w):
				c = QColor(self._image.pixel(x, y))
				nr, ng, nb = self._nearest_color((c.red(), c.green(), c.blue()), palette)
				self._image.setPixel(x, y, QColor(nr, ng, nb, c.alpha()).rgba())

	def _median_cut(self, pixels, n):
		if n <= 1 or not pixels:
			r = sum(p[0] for p in pixels) // len(pixels) if pixels else 0
			g = sum(p[1] for p in pixels) // len(pixels) if pixels else 0
			b = sum(p[2] for p in pixels) // len(pixels) if pixels else 0
			return [(r, g, b)]
		ranges = [max(p[i] for p in pixels) - min(p[i] for p in pixels) for i in range(3)]
		ch = ranges.index(max(ranges))
		pixels.sort(key=lambda p: p[ch])
		mid = len(pixels) // 2
		return (self._median_cut(pixels[:mid], n // 2) +
				self._median_cut(pixels[mid:], n - n // 2))

	def _nearest_color(self, color, palette):
		best = palette[0]; best_d = float('inf')
		for p in palette:
			d = (color[0]-p[0])**2 + (color[1]-p[1])**2 + (color[2]-p[2])**2
			if d < best_d:
				best_d = d; best = p
		return best

	def set_zoom(self, z):
		self._zoom = max(0.125, min(16.0, z))
		self._update_size()
		self.size_changed.emit(self._image.width(), self._image.height())
		self.update()

	# File ops
	def new_image(self, w=400, h=400):
		self._image = QImage(w, h, QImage.Format_ARGB32); self._image.fill(Qt.white)
		self._overlay = QImage(w, h, QImage.Format_ARGB32); self._overlay.fill(Qt.transparent)
		self._filename = ''; self._undo_stack.clear(); self._redo_stack.clear()
		self._sel_rect = None; self._polygon_pts = []; self._polygon_phase = 0; self._curve_phase = 0
		self._source_depth = None
		self._update_size(); self.update(); self._set_modified(False)
		self.size_changed.emit(w, h)

	@staticmethod
	def _pil_to_qimage(pil_img):
		"""Convert a PIL/Pillow Image to QImage (ARGB32)."""
		pil_img = pil_img.convert('RGBA')
		data = pil_img.tobytes('raw', 'BGRA')   # Qt ARGB32 = BGRA in memory on LE
		w, h = pil_img.size
		qi = QImage(data, w, h, w * 4, QImage.Format_ARGB32)
		return qi.copy()   # .copy() detaches from the Python buffer

	@staticmethod
	def _qimage_to_pil(qimage):
		"""Convert a QImage (ARGB32) to PIL RGBA Image."""
		from PIL import Image as _PILImage
		qimage = qimage.convertToFormat(QImage.Format_ARGB32)
		w, h = qimage.width(), qimage.height()
		ptr = qimage.bits(); ptr.setsize(h * w * 4)
		arr = bytes(ptr)
		# Qt stores as BGRA, PIL RGBA expects RGBA — swap channels
		pil = _PILImage.frombytes('RGBA', (w, h), arr, 'raw', 'BGRA')
		return pil

	def open_file(self, path):
		ext = Path(path).suffix.lower()

		if ext == '.jxl':
			# Prefer the native Qt JXL plugin (qt-jpegxl-image-plugin / kimageformats).
			# Fall back to pillow-jxl-plugin if the Qt plugin is not installed.
			img = QImage(path)
			if img.isNull():
				try:
					import pillow_jxl
					from PIL import Image as _PILImage
					pil_img = _PILImage.open(path)
					img = self._pil_to_qimage(pil_img)
					_jxl_pil_mode = pil_img.mode
				except ImportError:
					QMessageBox.critical(None, 'JXL not supported',
						'Opening JPEG XL files requires either:\n'
						'  • qt-jpegxl-image-plugin  (native Qt plugin, recommended)\n'
						'  • pillow-jxl-plugin		(pip install pillow-jxl-plugin)')
					return False
				except Exception as ex:
					QMessageBox.critical(None, 'Error opening JXL', str(ex))
					return False
			else:
				_jxl_pil_mode = None   # Qt plugin loaded it; depth read from QImage below
		else:
			img = QImage(path)
			_jxl_pil_mode = None

		if img.isNull(): return False

		# ── Capture source bit depth before convertToFormat destroys it ──────
		if ext == '.png':
			try:
				with open(path, 'rb') as _f: _hdr = _f.read(33)
				src_depth = _hdr[24]   # IHDR bit_depth byte — correct for 1/2/4/8/16
			except Exception:
				src_depth = None
		elif ext == '.jxl' and _jxl_pil_mode is not None:
			# Pillow fallback path — derive depth from PIL mode
			_jxl_depth = {'L':8,'P':8,'RGB':24,'RGBA':32,'RGBX':24,
						  'I;16':16,'I;16B':16,'F;16':16,'I':32,'F':32,'1':1}
			src_depth = _jxl_depth.get(_jxl_pil_mode, None)
		else:
			# Qt loaded the file — read depth from the pre-conversion QImage format
			_qt_depth = {
				QImage.Format_Mono: 1, QImage.Format_MonoLSB: 1,
				QImage.Format_Indexed8: 8,
				QImage.Format_RGB888: 24,
				QImage.Format_RGB32: 24, QImage.Format_ARGB32: 32,
				QImage.Format_ARGB32_Premultiplied: 32,
				QImage.Format_RGBA8888: 32, QImage.Format_RGBA8888_Premultiplied: 32,
				QImage.Format_RGB16: 16, QImage.Format_RGB555: 15, QImage.Format_RGB444: 12,
				QImage.Format_Grayscale8: 8, QImage.Format_Grayscale16: 16,
			}
			src_depth = _qt_depth.get(img.format(), None)

		self._push_undo()
		self._image = img.convertToFormat(QImage.Format_ARGB32)
		self._overlay = QImage(self._image.size(), QImage.Format_ARGB32)
		self._overlay.fill(Qt.transparent)
		self._filename = path; self._sel_rect = None
		self._source_depth = src_depth
		self._undo_stack.clear(); self._redo_stack.clear()
		self._update_size(); self.update(); self._set_modified(False)
		self.size_changed.emit(self._image.width(), self._image.height())
		return True

	def save_file(self, path):
		ext = Path(path).suffix.lower()
		if ext == '.jxl':
			# Try native Qt plugin first; fall back to pillow-jxl-plugin
			ok = self._image.save(path)
			if not ok:
				try:
					import pillow_jxl
					pil_img = self._qimage_to_pil(self._image)
					pil_img.save(path)
					ok = True
				except ImportError:
					QMessageBox.critical(None, 'JXL not supported',
						'Saving JPEG XL files requires either:\n'
						'  • qt-jpegxl-image-plugin  (native Qt plugin, recommended)\n'
						'  • pillow-jxl-plugin		(pip install pillow-jxl-plugin)')
					return False
				except Exception as ex:
					QMessageBox.critical(None, 'Error saving JXL', str(ex))
					return False
		elif ext == '.png':
			q = 0 if self._max_png_compression else -1
			ok = self._image.save(path, 'PNG', q)
		elif ext in ('.jpg', '.jpeg'):
			ok = self._image.save(path, 'JPEG', 90)
		else:
			ok = self._image.save(path)
		if ok:
			self._filename = path; self._set_modified(False)
		return ok

	def auto_save(self):
		if not self._auto_save_lossless or not self._filename: return
		ext = Path(self._filename).suffix.lower()
		if ext in ('.png', '.bmp'): self.save_file(self._filename)

	# Undo/Redo
	def _push_undo(self):
		self._undo_stack.append(self._image.copy())
		if len(self._undo_stack) > self.MAX_UNDO: self._undo_stack.pop(0)
		self._redo_stack.clear()

	def undo(self):
		if not self._undo_stack: return
		self._redo_stack.append(self._image.copy())
		self._image = self._undo_stack.pop()
		self._overlay = QImage(self._image.size(), QImage.Format_ARGB32)
		self._overlay.fill(Qt.transparent)
		self._sel_rect = None; self._update_size(); self.update()
		self.size_changed.emit(self._image.width(), self._image.height())

	def redo(self):
		if not self._redo_stack: return
		self._undo_stack.append(self._image.copy())
		self._image = self._redo_stack.pop()
		self._overlay = QImage(self._image.size(), QImage.Format_ARGB32)
		self._overlay.fill(Qt.transparent)
		self._sel_rect = None; self._update_size(); self.update()
		self.size_changed.emit(self._image.width(), self._image.height())

	# Clipboard
	def cut_selection(self):
		if not self._sel_rect: return
		self._copy_selection()
		self._push_undo()
		p = QPainter(self._image)
		if self._sel_free_pts and len(self._sel_free_pts) > 2:
			poly = QPolygon(self._sel_free_pts)
			if self._show_transparency:
				p.setCompositionMode(QPainter.CompositionMode_Clear)
				p.setPen(Qt.NoPen); p.setBrush(Qt.transparent)
			else:
				p.setPen(Qt.NoPen); p.setBrush(QBrush(Qt.white))
			p.drawPolygon(poly)
		else:
			if self._show_transparency:
				p.setCompositionMode(QPainter.CompositionMode_Clear)
			p.fillRect(self._sel_rect, Qt.transparent if self._show_transparency else Qt.white)
		p.end()
		self._sel_rect = None; self._sel_free_pts = []
		self._set_modified(True); self.update()

	def _copy_selection(self):
		if not self._sel_rect: return
		QApplication.clipboard().setImage(self._image.copy(self._sel_rect))

	def copy_selection(self): self._copy_selection()

	def paste(self):
		img = QApplication.clipboard().image()
		if img.isNull(): return
		self._push_undo()
		pasted = img.convertToFormat(QImage.Format_ARGB32)
		pw, ph = pasted.width(), pasted.height()
		iw, ih = self._image.width(), self._image.height()
		# If pasted image is larger than canvas, expand canvas to fit
		if pw > iw or ph > ih:
			new_w = max(pw, iw); new_h = max(ph, ih)
			new_canvas = QImage(new_w, new_h, QImage.Format_ARGB32)
			new_canvas.fill(Qt.white)
			p = QPainter(new_canvas); p.drawImage(0, 0, self._image); p.end()
			self._image = new_canvas
			self._overlay = QImage(new_w, new_h, QImage.Format_ARGB32)
			self._overlay.fill(Qt.transparent)
			self._update_size()
			self.size_changed.emit(new_w, new_h)
		self._floating = pasted
		self._floating_pos = QPoint(0, 0)
		self._sel_rect = QRect(0, 0, pw, ph)
		# Switch to selectrect without committing the floating we just set
		self._tool = 'selectrect'
		self._set_modified(True); self.update()

	# Transforms
	def rotate(self, deg):
		if self._floating:
			t=QTransform().rotate(deg); self._floating=self._floating.transformed(t,Qt.SmoothTransformation)
			old_rect=self._sel_rect or QRect(self._floating_pos,self._floating.size())
			cx=old_rect.x()+old_rect.width()//2; cy=old_rect.y()+old_rect.height()//2
			self._floating_pos=QPoint(cx-self._floating.width()//2,cy-self._floating.height()//2)
			self._sel_rect=QRect(self._floating_pos,self._floating.size())
			self.update(); self._set_modified(True); return
		self._push_undo()
		t=QTransform().rotate(deg); self._image=self._image.transformed(t,Qt.SmoothTransformation)
		self._overlay=QImage(self._image.size(),QImage.Format_ARGB32); self._overlay.fill(Qt.transparent)
		self._update_size(); self.update(); self._set_modified(True)
		self.size_changed.emit(self._image.width(),self._image.height())

	def flip(self, horizontal):
		if self._floating:
			self._floating=self._floating.mirrored(horizontal,not horizontal)
			self.update(); self._set_modified(True); return
		self._push_undo()
		self._image=self._image.mirrored(horizontal,not horizontal); self.update(); self._set_modified(True)

	def resize_image(self, w, h):
		if self._floating:
			self._floating=self._floating.scaled(w,h,Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
			self._sel_rect=QRect(self._floating_pos,self._floating.size())
			self.update(); self._set_modified(True); return
		self._push_undo()
		self._image=self._image.scaled(w,h,Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
		self._overlay=QImage(self._image.size(),QImage.Format_ARGB32); self._overlay.fill(Qt.transparent)
		self._update_size(); self.update(); self._set_modified(True); self.size_changed.emit(w,h)

	def crop_to_selection(self):
		if not self._sel_rect: return
		self._push_undo()
		self._image = self._image.copy(self._sel_rect)
		self._overlay = QImage(self._image.size(), QImage.Format_ARGB32)
		self._overlay.fill(Qt.transparent)
		self._sel_rect = None; self._update_size(); self.update(); self._set_modified(True)
		self.size_changed.emit(self._image.width(), self._image.height())

	def _commit_floating(self):
		"""Commit floating selection to the canvas image."""
		if not self._floating: return
		self._push_undo()
		p = QPainter(self._image)
		p.drawImage(self._floating_pos, self._floating)
		p.end()
		self._floating = None
		self._floating_drag = False
		self._floating_resize = False
		self._floating_resize_handle = None
		self._sel_rect = None
		self._set_modified(True); self.update()

	def _floating_handles(self):
		"""Return dict of handle_name -> (screen_x, screen_y) for the 8 resize handles."""
		if not self._sel_rect: return {}
		z = self._zoom
		r = self._sel_rect
		x1, y1 = int(r.x()*z), int(r.y()*z)
		x2, y2 = int((r.x()+r.width())*z), int((r.y()+r.height())*z)
		xm, ym = (x1+x2)//2, (y1+y2)//2
		return {
			'tl': (x1, y1), 'tc': (xm, y1), 'tr': (x2, y1),
			'ml': (x1, ym),                  'mr': (x2, ym),
			'bl': (x1, y2), 'bc': (xm, y2), 'br': (x2, y2),
		}

	def _floating_handle_at(self, screen_pos):
		"""Return handle name at screen_pos, or None."""
		if not self._sel_rect: return None
		hs = self._HANDLE_SIZE + 2
		for name, (hx, hy) in self._floating_handles().items():
			if abs(screen_pos.x()-hx) <= hs and abs(screen_pos.y()-hy) <= hs:
				return name
		return None

	def _floating_cursor_for_handle(self, h):
		corners = {'tl': Qt.SizeFDiagCursor, 'br': Qt.SizeFDiagCursor,
				   'tr': Qt.SizeBDiagCursor, 'bl': Qt.SizeBDiagCursor}
		edges   = {'tc': Qt.SizeVerCursor,   'bc': Qt.SizeVerCursor,
				   'ml': Qt.SizeHorCursor,   'mr': Qt.SizeHorCursor}
		return corners.get(h) or edges.get(h) or Qt.ArrowCursor

	def select_all(self):
		self._sel_rect = QRect(0, 0, self._image.width(), self._image.height())
		self.update()

	def delete_selection(self):
		if not self._sel_rect: return
		self._push_undo()
		p = QPainter(self._image)
		if self._sel_free_pts and len(self._sel_free_pts) > 2:
			poly = QPolygon(self._sel_free_pts)
			if self._show_transparency:
				p.setCompositionMode(QPainter.CompositionMode_Clear)
				p.setPen(Qt.NoPen); p.setBrush(Qt.transparent)
			else:
				p.setPen(Qt.NoPen); p.setBrush(QBrush(Qt.white))
			p.drawPolygon(poly)
		else:
			if self._show_transparency:
				p.setCompositionMode(QPainter.CompositionMode_Clear)
			p.fillRect(self._sel_rect, Qt.transparent if self._show_transparency else Qt.white)
		p.end()
		self._sel_rect = None; self._sel_free_pts = []
		self._set_modified(True); self.update()

	# Helpers
	def _update_size(self):
		hs = self._HANDLE_SIZE + 4  # extra margin for handles
		w = max(64, int(self._image.width()  * self._zoom) + 16 + hs)
		h = max(64, int(self._image.height() * self._zoom) + 16 + hs)
		self.setFixedSize(w, h)

	def _handle_positions(self):
		"""Returns (x,y) for right-mid, bottom-mid, bottom-right handles."""
		iw = int(self._image.width()  * self._zoom)
		ih = int(self._image.height() * self._zoom)
		return [
			(iw,	 ih // 2),   # right-middle
			(iw // 2, ih),	   # bottom-middle
			(iw,	 ih),		# bottom-right (corner)
		]

	def _handle_at(self, pos):
		"""Return 'right'|'bottom'|'corner'|None for the handle at pos."""
		hs = self._HANDLE_SIZE
		names = ['right', 'bottom', 'corner']
		for (hx, hy), name in zip(self._handle_positions(), names):
			if abs(pos.x() - hx) <= hs and abs(pos.y() - hy) <= hs:
				return name
		return None

	def _i(self, pt):
		"""Screen point -> image point."""
		return QPoint(max(0, min(self._image.width()-1,  int(pt.x() / self._zoom))),
					  max(0, min(self._image.height()-1, int(pt.y() / self._zoom))))

	def _if(self, pt):
		return QPointF(pt.x()/self._zoom, pt.y()/self._zoom)

	def _clear_overlay(self):
		self._overlay.fill(Qt.transparent)

	def _commit_overlay(self):
		p = QPainter(self._image); p.drawImage(0, 0, self._overlay); p.end()
		self._clear_overlay(); self._set_modified(True)

	def _mk_pen(self, color=None):
		if self._shape_outline == 0:
			return QPen(Qt.NoPen)
		c = color or self._fg
		return QPen(c, self._pen_width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)

	def _mk_brush(self):
		if self._shape_fill == 1:
			return QBrush(self._bg)
		return QBrush(Qt.NoBrush)

	# ─── Shape geometry ───────────────────────────────────────────────────────
	def _norm(self, x1, y1, x2, y2):
		if x1 > x2: x1, x2 = x2, x1
		if y1 > y2: y1, y2 = y2, y1
		if x1 == x2: x2 += 1
		if y1 == y2: y2 += 1
		return x1, y1, x2, y2

	def _reg_poly(self, x1,y1,x2,y2,n):
		cx=(x1+x2)/2; cy=(y1+y2)/2; r=min(abs(x2-x1),abs(y2-y1))/2
		pts=[]
		for i in range(n):
			a=math.pi*(2*i/n - 0.5)
			pts.append(QPoint(int(cx+r*math.cos(a)), int(cy+r*math.sin(a))))
		return QPolygon(pts)

	def _star(self, x1,y1,x2,y2,n,inner=0.4):
		cx=(x1+x2)/2; cy=(y1+y2)/2; r=min(abs(x2-x1),abs(y2-y1))/2; ri=r*inner
		pts=[]
		for i in range(n*2):
			a=math.pi*(i/n - 0.5); rad=r if i%2==0 else ri
			pts.append(QPoint(int(cx+rad*math.cos(a)), int(cy+rad*math.sin(a))))
		return QPolygon(pts)

	def _arrow(self, x1,y1,x2,y2,d):
		w=x2-x1; h=y2-y1; cx=(x1+x2)//2; cy=(y1+y2)//2
		if d=='right':
			hw=w//3; ah=h//3
			return QPolygon([QPoint(x1,cy-ah),QPoint(x2-hw,cy-ah),QPoint(x2-hw,y1),
							 QPoint(x2,cy),QPoint(x2-hw,y2),QPoint(x2-hw,cy+ah),QPoint(x1,cy+ah)])
		if d=='left':
			hw=w//3; ah=h//3
			return QPolygon([QPoint(x2,cy-ah),QPoint(x1+hw,cy-ah),QPoint(x1+hw,y1),
							 QPoint(x1,cy),QPoint(x1+hw,y2),QPoint(x1+hw,cy+ah),QPoint(x2,cy+ah)])
		if d=='up':
			hw=w//3; ah=h//3
			return QPolygon([QPoint(cx-hw,y2),QPoint(cx-hw,y1+ah),QPoint(x1,y1+ah),
							 QPoint(cx,y1),QPoint(x2,y1+ah),QPoint(cx+hw,y1+ah),QPoint(cx+hw,y2)])
		# down
		hw=w//3; ah=h//3
		return QPolygon([QPoint(cx-hw,y1),QPoint(cx-hw,y2-ah),QPoint(x1,y2-ah),
						 QPoint(cx,y2),QPoint(x2,y2-ah),QPoint(cx+hw,y2-ah),QPoint(cx+hw,y1)])

	def _heart_path(self, x1,y1,x2,y2):
		w=x2-x1; h=y2-y1
		def P(nx,ny): return QPointF(x1+nx*w, y1+ny*h)
		path=QPainterPath(P(0.5,0.25))
		path.cubicTo(P(0.5,0.0),P(1.0,0.0),P(1.0,0.35))
		path.cubicTo(P(1.0,0.65),P(0.5,0.8),P(0.5,1.0))
		path.cubicTo(P(0.5,0.8),P(0.0,0.65),P(0.0,0.35))
		path.cubicTo(P(0.0,0.0),P(0.5,0.0),P(0.5,0.25))
		path.closeSubpath(); return path

	def _lightning_poly(self, x1,y1,x2,y2):
		w=x2-x1; h=y2-y1
		# Shape matches the SVG icon: points="38,6 18,34 30,34 26,58 46,28 34,28" on 64x64
		return QPolygon([
			QPoint(x1+int(w*0.5938), y1+int(h*0.0938)),
			QPoint(x1+int(w*0.2812), y1+int(h*0.5312)),
			QPoint(x1+int(w*0.4688), y1+int(h*0.5312)),
			QPoint(x1+int(w*0.4062), y1+int(h*0.9062)),
			QPoint(x1+int(w*0.7188), y1+int(h*0.4375)),
			QPoint(x1+int(w*0.5312), y1+int(h*0.4375)),
		])

	def _callout_rect_path(self, x1,y1,x2,y2):
		bh=(y2-y1)*3//4; path=QPainterPath()
		path.addRoundedRect(x1,y1,x2-x1,bh,10,10)
		tx=x1+(x2-x1)//4
		path.moveTo(tx,y1+bh); path.lineTo(tx-12,y2); path.lineTo(tx+12,y1+bh)
		path.closeSubpath(); return path

	def _callout_oval_path(self, x1,y1,x2,y2):
		bh=(y2-y1)*3//4; bw=x2-x1; path=QPainterPath()
		path.addEllipse(x1,y1,bw,bh)
		tx=x1+bw//4
		path.moveTo(tx,y1+bh); path.lineTo(tx-10,y2); path.lineTo(tx+10,y1+bh)
		path.closeSubpath(); return path

	def _callout_cloud_path(self, x1,y1,x2,y2):
		w=x2-x1; h=y2-y1
		# Shape matches SVG icon (64x64 canvas):
		# M18,34 Q10,34 10,26 Q10,18 18,18 Q18,10 26,10 Q30,6 36,8 Q42,6 46,12
		# Q54,12 54,20 Q58,24 54,28 Q54,34 46,34 Z
		# tail: polygon 16,34 22,38 12,54
		def P(fx, fy): return QPointF(x1 + fx*w, y1 + fy*h)
		path = QPainterPath(P(0.2812, 0.5312))
		path.quadTo(P(0.1562, 0.5312), P(0.1562, 0.4062))
		path.quadTo(P(0.1562, 0.2812), P(0.2812, 0.2812))
		path.quadTo(P(0.2812, 0.1562), P(0.4062, 0.1562))
		path.quadTo(P(0.4688, 0.0938), P(0.5625, 0.1250))
		path.quadTo(P(0.6562, 0.0938), P(0.7188, 0.1875))
		path.quadTo(P(0.8438, 0.1875), P(0.8438, 0.3125))
		path.quadTo(P(0.9062, 0.3750), P(0.8438, 0.4375))
		path.quadTo(P(0.8438, 0.5312), P(0.7188, 0.5312))
		path.closeSubpath()
		# Tail pointer
		tail = QPainterPath(P(0.2500, 0.5312))
		tail.lineTo(P(0.3438, 0.5938))
		tail.lineTo(P(0.1875, 0.8438))
		tail.closeSubpath()
		path.addPath(tail)
		return path

	def _draw_shape(self, painter, shape, x1,y1,x2,y2):
		if shape != 'line':
			x1, y1, x2, y2 = self._norm(x1, y1, x2, y2)
		painter.setRenderHint(QPainter.Antialiasing)
		painter.setPen(self._mk_pen())
		painter.setBrush(self._mk_brush())

		if   shape=='line':
			p = QPen(self._fg if self._shape_outline else Qt.NoPen,
					 self._pen_width, Qt.SolidLine, Qt.RoundCap, Qt.RoundJoin)
			painter.setPen(p); painter.setBrush(Qt.NoBrush)
			painter.drawLine(x1,y1,x2,y2)
		elif shape=='ellipse':	painter.drawEllipse(x1,y1,x2-x1,y2-y1)
		elif shape=='rect':	   painter.drawRect(x1,y1,x2-x1,y2-y1)
		elif shape=='roundrect':
			rx=max(8,(x2-x1)//8); ry=max(8,(y2-y1)//8)
			painter.drawRoundedRect(x1,y1,x2-x1,y2-y1,rx,ry)
		elif shape=='triangle':
			cx=(x1+x2)//2
			painter.drawPolygon(QPolygon([QPoint(cx,y1),QPoint(x2,y2),QPoint(x1,y2)]))
		elif shape=='right_triangle':
			painter.drawPolygon(QPolygon([QPoint(x1,y1),QPoint(x2,y2),QPoint(x1,y2)]))
		elif shape=='diamond':
			cx=(x1+x2)//2; cy=(y1+y2)//2
			painter.drawPolygon(QPolygon([QPoint(cx,y1),QPoint(x2,cy),QPoint(cx,y2),QPoint(x1,cy)]))
		elif shape=='pentagon':  painter.drawPolygon(self._reg_poly(x1,y1,x2,y2,5))
		elif shape=='hexagon':   painter.drawPolygon(self._reg_poly(x1,y1,x2,y2,6))
		elif shape=='poly8':	 painter.drawPolygon(self._reg_poly(x1,y1,x2,y2,8))
		elif shape=='star4':	 painter.drawPolygon(self._star(x1,y1,x2,y2,4,0.35))
		elif shape=='star5':	 painter.drawPolygon(self._star(x1,y1,x2,y2,5,0.38))
		elif shape=='star6':	 painter.drawPolygon(self._star(x1,y1,x2,y2,6,0.5))
		elif shape=='right_arrow': painter.drawPolygon(self._arrow(x1,y1,x2,y2,'right'))
		elif shape=='left_arrow':  painter.drawPolygon(self._arrow(x1,y1,x2,y2,'left'))
		elif shape=='up_arrow':	painter.drawPolygon(self._arrow(x1,y1,x2,y2,'up'))
		elif shape=='down_arrow':  painter.drawPolygon(self._arrow(x1,y1,x2,y2,'down'))
		elif shape=='heart':	   painter.drawPath(self._heart_path(x1,y1,x2,y2))
		elif shape=='lightning':   painter.drawPolygon(self._lightning_poly(x1,y1,x2,y2))
		elif shape=='callout_rect': painter.drawPath(self._callout_rect_path(x1,y1,x2,y2))
		elif shape=='callout_oval': painter.drawPath(self._callout_oval_path(x1,y1,x2,y2))
		elif shape=='callout_cloud':painter.drawPath(self._callout_cloud_path(x1,y1,x2,y2))

	# ─── Paint event ──────────────────────────────────────────────────────────
	def paintEvent(self, e):
		p = QPainter(self)
		z = self._zoom
		iw = int(self._image.width() * z)
		ih = int(self._image.height() * z)

		# Checkerboard or white background — image area only, not beyond
		if self._show_transparency:
			tile = 8
			for ty in range(0, ih, tile):
				for tx in range(0, iw, tile):
					c = QColor(200,200,200) if ((tx//tile+ty//tile)%2==0) else QColor(150,150,150)
					p.fillRect(tx, ty, min(tile, iw-tx), min(tile, ih-ty), c)
		else:
			p.fillRect(0, 0, iw, ih, Qt.white)
		# Draw image
		scaled = self._image.scaled(iw, ih, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
		p.drawImage(0, 0, scaled)

		# Overlay
		if not self._overlay.isNull():
			so = self._overlay.scaled(iw, ih, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
			p.drawImage(0, 0, so)

		# Selection rect
		if self._sel_rect:
			p.setPen(QPen(QColor(0,0,0), 1, Qt.DashLine))
			p.setBrush(Qt.NoBrush)
			p.drawRect(QRect(int(self._sel_rect.x()*z), int(self._sel_rect.y()*z),
							 int(self._sel_rect.width()*z), int(self._sel_rect.height()*z)))

		# Free-form lasso in progress — draw directly in screen space
		if self._tool == 'select' and self._drawing and len(self._sel_free_screen) > 1:
			p.setPen(QPen(QColor(0,0,0), 1, Qt.DashLine))
			for i in range(len(self._sel_free_screen)-1):
				p.drawLine(self._sel_free_screen[i], self._sel_free_screen[i+1])

		# Gridlines
		if self._show_gridlines:
			p.setPen(QPen(QColor(180,180,180,100), 1))
			step = max(1, int(20*z))
			for x in range(0, self.width(), step): p.drawLine(x,0,x,self.height())
			for y in range(0, self.height(), step): p.drawLine(0,y,self.width(),y)

		# Polygon preview
		if self._tool == 'polygon' and self._polygon_pts:
			p.setPen(QPen(self._fg, self._pen_width, Qt.SolidLine))
			pts = [QPoint(int(pt.x()*z), int(pt.y()*z)) for pt in self._polygon_pts]
			for i in range(len(pts)-1):
				p.drawLine(pts[i], pts[i+1])
			# Rubber-band: line from last point to current mouse (phase 1 or 2)
			if self._polygon_phase in (1, 2) and not self._polygon_mouse.isNull():
				mp = QPoint(int(self._polygon_mouse.x()*z), int(self._polygon_mouse.y()*z))
				p.setPen(QPen(self._fg, self._pen_width, Qt.DashLine))
				p.drawLine(pts[-1], mp)
				# Show close-snap indicator near start point
				if len(pts) >= 3:
					snap_r = max(8, self._pen_width*3)
					p.setPen(QPen(self._fg, 1, Qt.DotLine))
					p.setBrush(Qt.NoBrush)
					p.drawEllipse(pts[0], snap_r, snap_r)

		# Floating selection (paste or moved selection)
		if self._floating:
			fx = int(self._floating_pos.x() * z)
			fy = int(self._floating_pos.y() * z)
			fw = int(self._floating.width() * z)
			fh = int(self._floating.height() * z)
			scaled_f = self._floating.scaled(fw, fh, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
			p.drawImage(fx, fy, scaled_f)
			# Dashed border around floating selection
			p.setPen(QPen(QColor(0,0,0), 1, Qt.DashLine))
			p.setBrush(Qt.NoBrush)
			p.drawRect(fx, fy, fw-1, fh-1)

		# Selection handles — shown whenever sel_rect is set (floating or plain selection)
		if self._sel_rect and not self._drawing:
			hs = self._HANDLE_SIZE
			for hx, hy in self._floating_handles().values():
				p.fillRect(hx - hs//2, hy - hs//2, hs, hs, QColor(255, 255, 255))
				p.setPen(QPen(QColor(0, 0, 0), 1))
				p.drawRect(hx - hs//2, hy - hs//2, hs-1, hs-1)

		# Canvas resize handles: right-mid, bottom-mid, bottom-right
		hs = self._HANDLE_SIZE
		for hx, hy in self._handle_positions():
			p.fillRect(hx - hs//2, hy - hs//2, hs, hs, QColor(255, 255, 255))
			p.setPen(QPen(QColor(100, 100, 100), 1))
			p.drawRect(hx - hs//2, hy - hs//2, hs - 1, hs - 1)

		# Resize preview: dashed outline showing new size while dragging
		if self._resize_preview:
			pw = int(self._resize_preview.width() * z)
			ph = int(self._resize_preview.height() * z)
			p.setPen(QPen(QColor(80, 80, 255), 1, Qt.DashLine))
			p.setBrush(Qt.NoBrush)
			p.drawRect(0, 0, pw - 1, ph - 1)

		p.end()

	# ─── Mouse ────────────────────────────────────────────────────────────────
	def mousePressEvent(self, e):
		# Check resize handles first
		h = self._handle_at(e.pos())
		if h:
			self._resizing = True
			self._resize_handle = h
			self._resize_start_pos = e.globalPos()
			self._resize_start_size = QSize(self._image.width(), self._image.height())
			e.accept()
			return

		ip = self._i(e.pos())
		btn = e.button()
		color = self._fg if btn == Qt.LeftButton else self._bg

		# Shift+click: emit pixel color to status bar
		if e.modifiers() & Qt.ShiftModifier:
			px = self._image.pixel(max(0,min(ip.x(),self._image.width()-1)),
								   max(0,min(ip.y(),self._image.height()-1)))
			r,g,b = (px>>16)&0xff, (px>>8)&0xff, px&0xff
			self.pixel_picked.emit(r, g, b)
			return

		# Handle/drag interaction with sel_rect (works with or without floating)
		if self._sel_rect and not self._drawing:
			h = self._floating_handle_at(e.pos())
			if h:
				self._floating_resize = True
				self._floating_resize_handle = h
				self._floating_resize_start_pos = e.globalPos()
				self._floating_resize_start_rect = QRect(self._sel_rect)
				e.accept(); return
			if self._floating:
				fr = QRect(self._floating_pos, QSize(self._floating.width(), self._floating.height()))
				if fr.contains(ip):
					self._floating_drag = True
					self._floating_drag_start = ip - self._floating_pos
					e.accept(); return
				else:
					self._commit_floating()
			elif self._sel_rect.contains(ip):
				# Plain selection drag — lift to floating first
				self._floating = self._image.copy(self._sel_rect)
				pp = QPainter(self._image)
				if self._show_transparency:
					pp.setCompositionMode(QPainter.CompositionMode_Clear)
				pp.fillRect(self._sel_rect, Qt.transparent if self._show_transparency else Qt.white)
				pp.end()
				self._floating_pos = self._sel_rect.topLeft()
				self._floating_drag = True
				self._floating_drag_start = ip - self._floating_pos
				e.accept(); return
			else:
				self._sel_rect = None
				self._sel_free_pts = []

		if self._tool == 'pencil':
			self._push_undo(); self._drawing = True
			self._last_screen=QPointF(e.pos()); self._last=ip; self._put_pixel(ip, color)

		elif self._tool == 'brush':
			self._push_undo(); self._drawing = True
			self._last_screen=QPointF(e.pos()); self._last=ip; self._put_brush(ip, color)

		elif self._tool == 'eraser':
			self._push_undo(); self._drawing = True
			self._last_screen=QPointF(e.pos()); self._last=ip; self._put_eraser(ip)

		elif self._tool == 'fill':
			self._push_undo(); self._flood_fill(ip, color)
			self._set_modified(True); self.update()

		elif self._tool == 'picker':
			px = self._image.pixel(ip)
			c = QColor(px); c.setAlpha(255)
			is_fg = (btn == Qt.LeftButton)
			if is_fg: self._fg = c
			else:	 self._bg = c
			self.color_changed.emit(c, is_fg)

		elif self._tool == 'magnifier':
			self.set_zoom(self._zoom * 2 if btn == Qt.LeftButton else self._zoom / 2)

		elif self._tool == 'text':
			text, ok = QInputDialog.getText(self, 'Text', 'Enter text:')
			if ok and text:
				self._push_undo()
				p = QPainter(self._image)
				p.setPen(QPen(color)); p.setFont(QFont('Arial', 14))
				p.drawText(ip, text); p.end()
				self._set_modified(True); self.update()

		elif self._tool == 'selectrect':
			self._drawing = True; self._start = ip
			# If click is inside existing selection, lift it to floating and drag
			if self._sel_rect and self._sel_rect.contains(ip):
				self._floating = self._image.copy(self._sel_rect)
				# Clear original area
				p = QPainter(self._image)
				if self._show_transparency:
					p.setCompositionMode(QPainter.CompositionMode_Clear)
				p.fillRect(self._sel_rect, Qt.transparent if self._show_transparency else Qt.white)
				p.end()
				self._floating_pos = self._sel_rect.topLeft()
				self._floating_drag = True
				self._floating_drag_start = ip - self._floating_pos
				self._drawing = False
			else:
				self._sel_rect = None; self._sel_free_pts = []; self._floating = None

		elif self._tool == 'select':
			# Check if clicking inside existing selection BEFORE resetting
			if self._sel_rect and self._sel_rect.contains(ip) and self._sel_free_pts:
				# Lift existing free-form selection to floating
				self._floating = self._image.copy(self._sel_rect)
				p = QPainter(self._image)
				if self._show_transparency:
					p.setCompositionMode(QPainter.CompositionMode_Clear)
				poly = QPolygon(self._sel_free_pts)
				p.setPen(Qt.NoPen)
				p.setBrush(Qt.transparent if self._show_transparency else Qt.white)
				p.drawPolygon(poly); p.end()
				self._floating_pos = self._sel_rect.topLeft()
				self._floating_drag = True
				self._floating_drag_start = ip - self._floating_pos
				self._drawing = False
				self._sel_rect = None
			else:
				self._drawing = True; self._sel_rect = None
				self._sel_free_pts = []; self._sel_free_screen = [QPoint(e.pos())]

		elif self._tool == 'polygon':
			if btn == Qt.LeftButton:
				if self._polygon_phase == 0:
					# Phase 1: start dragging first segment
					self._push_undo()
					self._polygon_pts = [ip]
					self._polygon_phase = 1
					self._drawing = True
				elif self._polygon_phase == 2:
					# Check if clicking near start to close polygon
					if len(self._polygon_pts) >= 3:
						start = self._polygon_pts[0]
						snap_r = max(8, self._pen_width*3)
						if (abs(ip.x()-start.x()) <= snap_r and abs(ip.y()-start.y()) <= snap_r):
							self._finish_polygon()
							return
					# Add new vertex
					self._polygon_pts.append(ip)
					self._polygon_mouse = ip
					self.update()
			elif btn == Qt.RightButton:
				if self._polygon_phase in (1, 2):
					self._finish_polygon()

		elif self._tool == '__shape__':
			if self._shape == 'curve':
				if self._curve_phase == 0:
					# First click: start point
					self._push_undo()
					self._drawing = True
					self._curve_start = ip; self._curve_end = ip; self._curve_ctrl = ip
					self._curve_phase = 1
				else:
					# Second click: fix control point
					self._commit_overlay()
					self._curve_phase = 0; self._drawing = False
					self.auto_save(); self.update()
			else:
				self._push_undo()
				self._drawing = True; self._start = ip

		self._last = ip

	def mouseMoveEvent(self, e):
		# Update cursor for handles
		h = self._handle_at(e.pos())
		if self._resizing:
			delta = e.globalPos() - self._resize_start_pos
			sw = self._resize_start_size.width()
			sh = self._resize_start_size.height()
			dxi = int(delta.x() / self._zoom)
			dyi = int(delta.y() / self._zoom)
			if self._resize_handle == 'right':
				new_w = max(1, sw + dxi); new_h = sh
			elif self._resize_handle == 'bottom':
				new_w = sw; new_h = max(1, sh + dyi)
			else:  # corner
				new_w = max(1, sw + dxi); new_h = max(1, sh + dyi)
				# Ctrl held = maintain aspect ratio
				if e.modifiers() & Qt.ControlModifier and sw > 0 and sh > 0:
					ratio = sw / sh
					if abs(dxi) >= abs(dyi):
						new_h = max(1, int(new_w / ratio))
					else:
						new_w = max(1, int(new_h * ratio))
			self._resize_preview = QSize(new_w, new_h)
			self.update()
			e.accept()
			return
		if h == 'corner':
			self.setCursor(Qt.SizeFDiagCursor)
		elif h == 'right':
			self.setCursor(Qt.SizeHorCursor)
		elif h == 'bottom':
			self.setCursor(Qt.SizeVerCursor)
		else:
			# Check selection handles for cursor
			if self._sel_rect and not self._floating_drag and not self._floating_resize and not self._drawing:
				fh_name = self._floating_handle_at(e.pos())
				if fh_name:
					self.setCursor(self._floating_cursor_for_handle(fh_name))
				elif self._sel_rect.contains(self._i(e.pos())):
					self.setCursor(Qt.SizeAllCursor)
				else:
					self._update_cursor()
			else:
				self._update_cursor()

		ip = self._i(e.pos())
		self.cursor_moved.emit(ip.x(), ip.y())

		if self._floating_resize:
			delta = e.globalPos() - self._floating_resize_start_pos
			dx = int(delta.x() / self._zoom)
			dy = int(delta.y() / self._zoom)
			r = self._floating_resize_start_rect
			x1, y1, x2, y2 = r.left(), r.top(), r.right(), r.bottom()
			h_name = self._floating_resize_handle
			if 'l' in h_name: x1 = min(x2 - 1, x1 + dx)
			if 'r' in h_name: x2 = max(x1 + 1, x2 + dx)
			if 't' in h_name: y1 = min(y2 - 1, y1 + dy)
			if 'b' in h_name: y2 = max(y1 + 1, y2 + dy)
			self._sel_rect = QRect(QPoint(x1, y1), QPoint(x2, y2))
			self._floating_pos = QPoint(x1, y1)
			self.update(); e.accept(); return

		if self._floating_drag:
			raw_pos = ip - self._floating_drag_start
			# Clamp so selection stays within canvas
			fw = self._floating.width(); fh = self._floating.height()
			cx = max(0, min(self._image.width()  - fw, raw_pos.x()))
			cy = max(0, min(self._image.height() - fh, raw_pos.y()))
			self._floating_pos = QPoint(cx, cy)
			self._sel_rect = QRect(self._floating_pos, QSize(fw, fh))
			self.update(); e.accept(); return
		color = self._fg if (e.buttons() & Qt.LeftButton) else self._bg

		if self._tool == '__shape__' and self._shape == 'curve' and self._curve_phase == 1:
			# Phase 1: dragging end point
			self._curve_end = ip
			self._curve_ctrl = QPoint((self._curve_start.x()+ip.x())//2,
									   (self._curve_start.y()+ip.y())//2 - 20)
			self._clear_overlay()
			p = QPainter(self._overlay); p.setRenderHint(QPainter.Antialiasing)
			p.setPen(self._mk_pen()); p.setBrush(Qt.NoBrush)
			path = QPainterPath(QPointF(self._curve_start))
			path.quadTo(QPointF(self._curve_ctrl), QPointF(ip))
			p.drawPath(path); p.end(); self.update(); return

		if not self._drawing: return

		if self._tool == 'pencil':
			cur=QPointF(e.pos()); self._draw_pencil_line(self._if(self._last_screen),self._if(cur),color)
			self._last_screen=cur; self._last=ip; self.update()

		elif self._tool == 'brush':
			cur=QPointF(e.pos()); self._draw_brush_line(self._if(self._last_screen),self._if(cur),color)
			self._last_screen=cur; self._last=ip; self.update()

		elif self._tool == 'eraser':
			cur=QPointF(e.pos()); self._draw_eraser_line(self._if(self._last_screen),self._if(cur))
			self._last_screen=cur; self._last=ip; self.update()

		elif self._tool == 'selectrect':
			self._sel_rect = QRect(self._start, ip).normalized(); self.update()

		elif self._tool == 'select':
			if self._drawing:
				self._sel_free_screen.append(QPoint(e.pos()))
				self.update()

		elif self._tool == 'polygon':
			self._polygon_mouse = ip
			if self._polygon_phase == 1 and self._drawing:
				# Live drag of the first segment end point
				if len(self._polygon_pts) == 1:
					pass  # just update mouse, preview handles it
				self.update()
			elif self._polygon_phase == 2:
				self.update()

		elif self._tool == '__shape__':
			self._clear_overlay()
			p = QPainter(self._overlay)
			ix, iy = ip.x(), ip.y()
			if e.modifiers() & Qt.ControlModifier:
				# Constrain to square
				dx = ix - self._start.x(); dy = iy - self._start.y()
				s = min(abs(dx), abs(dy))
				ix = self._start.x() + (s if dx >= 0 else -s)
				iy = self._start.y() + (s if dy >= 0 else -s)
			self._draw_shape(p, self._shape, self._start.x(), self._start.y(), ix, iy)
			p.end(); self.update()

	def mouseReleaseEvent(self, e):
		if self._floating_resize:
			new_w = max(1, self._sel_rect.width())
			new_h = max(1, self._sel_rect.height())
			if self._floating:
				# Rescale floating image to new rect size
				self._floating = self._floating.scaled(new_w, new_h, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)
				self._floating_pos = self._sel_rect.topLeft()
				self._sel_rect = QRect(self._floating_pos, QSize(new_w, new_h))
			# For plain selection, sel_rect already updated during drag — nothing extra needed
			self._floating_resize = False
			self._floating_resize_handle = None
			self.update(); e.accept(); return

		if self._floating_drag:
			self._floating_drag = False
			self.update(); e.accept(); return

		if self._resizing:
			self._resizing=False; self._resize_handle=None
			if hasattr(self,'_resize_preview') and self._resize_preview:
				new_w=self._resize_preview.width(); new_h=self._resize_preview.height()
				self._push_undo()
				if self._pinch_stretch:
					new_img=self._image.scaled(new_w,new_h,Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
					self._image=new_img.convertToFormat(QImage.Format_ARGB32)
				else:
					new_img=QImage(new_w,new_h,QImage.Format_ARGB32); new_img.fill(Qt.white)
					p2=QPainter(new_img); p2.drawImage(0,0,self._image); p2.end()
					self._image=new_img
				self._overlay=QImage(new_w,new_h,QImage.Format_ARGB32); self._overlay.fill(Qt.transparent)
				self._resize_preview=None; self._update_size()
				self.size_changed.emit(new_w,new_h); self._set_modified(True); self.update()
			e.accept(); return

		ip = self._i(e.pos())

		if self._tool in ('pencil','brush','eraser'):
			self._drawing = False; self._set_modified(True); self.auto_save()

		elif self._tool == 'selectrect':
			self._drawing = False
			self._sel_rect = QRect(self._start, ip).normalized(); self.update()

		elif self._tool == 'select':
			self._drawing = False
			if len(self._sel_free_screen) > 2:
				# Convert screen points to image points
				self._sel_free_pts = [self._i(sp) for sp in self._sel_free_screen]
				self._sel_free_pts.append(self._sel_free_pts[0])  # close loop
				xs = [p.x() for p in self._sel_free_pts]
				ys = [p.y() for p in self._sel_free_pts]
				self._sel_rect = QRect(QPoint(min(xs),min(ys)), QPoint(max(xs),max(ys)))
			self._sel_free_screen = []
			self.update()

		elif self._tool == 'polygon' and self._polygon_phase == 1:
			# First segment drag released: fix the end point, switch to click mode
			if len(self._polygon_pts) >= 1 and ip != self._polygon_pts[0]:
				self._polygon_pts.append(ip)
			self._polygon_phase = 2
			self._drawing = False
			self._polygon_mouse = ip
			self.update()

		elif self._tool == '__shape__' and self._shape != 'curve':
			# Render shape into a floating image instead of committing directly
			x1, y1 = self._start.x(), self._start.y()
			x2, y2 = ip.x(), ip.y()
			if e.modifiers() & Qt.ControlModifier:
				dx = x2-x1; dy = y2-y1; s = min(abs(dx),abs(dy))
				x2 = x1+(s if dx>=0 else -s); y2 = y1+(s if dy>=0 else -s)
			# Bounding rect in image coords
			rx, ry = min(x1,x2), min(y1,y2)
			rw, rh = max(1, abs(x2-x1)), max(1, abs(y2-y1))
			# Render shape into a transparent QImage
			shape_img = QImage(rw, rh, QImage.Format_ARGB32)
			shape_img.fill(Qt.transparent)
			sp = QPainter(shape_img); sp.setRenderHint(QPainter.Antialiasing)
			sp.setPen(self._mk_pen()); sp.setBrush(self._mk_brush())
			self._draw_shape(sp, self._shape, 0, 0, rw-1, rh-1)
			sp.end()
			self._clear_overlay()
			self._floating = shape_img
			self._floating_pos = QPoint(rx, ry)
			self._sel_rect = QRect(rx, ry, rw, rh)
			self._drawing = False
			self.update()

	def wheelEvent(self, e):
		if e.modifiers() & Qt.ControlModifier:
			delta = e.angleDelta().y()
			if delta > 0:
				self.set_zoom(round(min(16.0, self._zoom + 0.1), 2))
			elif delta < 0:
				self.set_zoom(round(max(0.1, self._zoom - 0.1), 2))
			e.accept()
		else:
			super().wheelEvent(e)

	def _finish_polygon(self):
		if self._tool == 'polygon' and len(self._polygon_pts) >= 3:
			pts = self._polygon_pts
			xs = [pt.x() for pt in pts]; ys = [pt.y() for pt in pts]
			rx, ry = min(xs), min(ys)
			rw, rh = max(1, max(xs)-rx), max(1, max(ys)-ry)
			# Render polygon into a transparent floating image
			shape_img = QImage(rw, rh, QImage.Format_ARGB32)
			shape_img.fill(Qt.transparent)
			sp = QPainter(shape_img); sp.setRenderHint(QPainter.Antialiasing)
			sp.setPen(self._mk_pen()); sp.setBrush(self._mk_brush())
			shifted = QPolygon([QPoint(pt.x()-rx, pt.y()-ry) for pt in pts])
			sp.drawPolygon(shifted); sp.end()
			self._floating = shape_img
			self._floating_pos = QPoint(rx, ry)
			self._sel_rect = QRect(rx, ry, rw, rh)
		self._polygon_pts = []; self._polygon_phase = 0
		self._polygon_mouse = QPoint(); self._drawing = False
		self.update()

	# ─── Primitives ───────────────────────────────────────────────────────────
	def _put_pixel(self, pt, color):
		p = QPainter(self._image)
		p.setPen(QPen(color, self._pen_width)); p.drawPoint(pt); p.end(); self.update()

	def _draw_pencil_line(self, p1, p2, color):
		p=QPainter(self._image)
		p.setPen(QPen(color,self._pen_width,Qt.SolidLine,Qt.SquareCap,Qt.MiterJoin))
		p.setRenderHint(QPainter.Antialiasing,False); p.drawLine(QPointF(p1),QPointF(p2)); p.end()

	def _put_brush(self, pt, color):
		# sz = pen_width = exact stroke diameter. r = sz/2 = radius.
		p=QPainter(self._image); bt=self._brush_type
		sz=max(1, self._pen_width)
		r=sz/2.0
		x, y = pt.x(), pt.y()

		if bt=='Normal':
			alpha=int(255*self._brush_hardness/100); c2=QColor(color); c2.setAlpha(alpha)
			if self._brush_shape=='square':
				p.setPen(Qt.NoPen); p.setBrush(QBrush(c2))
				p.drawRect(int(x-r), int(y-r), sz, sz)
			else:
				p.setRenderHint(QPainter.Antialiasing); p.setPen(Qt.NoPen)
				p.setBrush(QBrush(c2))
				p.drawEllipse(QPointF(x, y), r, r)

		elif bt=='Calligraphy 1':
			p.setRenderHint(QPainter.Antialiasing)
			p.setPen(QPen(color, sz, Qt.SolidLine, Qt.FlatCap, Qt.MiterJoin))
			p.drawLine(QPointF(x - r, y - r), QPointF(x + r, y + r))

		elif bt=='Calligraphy 2':
			h = max(1, sz)
			w = max(h * 3, sz + 2)
			p.setPen(Qt.NoPen); p.setBrush(QBrush(QColor(color)))
			p.drawRect(int(x - w/2), int(y - h/2), w, h)

		elif bt=='Airbrush':
			# Polar coords so cloud diameter = sz exactly (round not int)
			p.setPen(QPen(color, 1))
			count = max(6, sz * 2)
			for _ in range(count):
				angle = random.uniform(0, 2 * math.pi)
				dist  = random.uniform(0, r)
				p.drawPoint(x + round(dist * math.cos(angle)),
							y + round(dist * math.sin(angle)))

		elif bt=='Oil Brush':
			# Float offsets so sz=1/2/3 produce visibly different sizes
			p.setRenderHint(QPainter.Antialiasing)
			count = max(3, sz)
			for _ in range(count):
				c2 = QColor(color); c2.setAlpha(60 + random.randint(0, 80))
				p.setPen(Qt.NoPen); p.setBrush(QBrush(c2))
				ox = random.uniform(-r/2, r/2)
				oy = random.uniform(-r/2, r/2)
				er = max(0.5, r - max(abs(ox), abs(oy)))
				p.drawEllipse(QPointF(x + ox, y + oy), er, er * 0.55)

		elif bt=='Watercolor':
			c2 = QColor(color); c2.setAlpha(50)
			p.setPen(Qt.NoPen); p.setBrush(QBrush(c2))
			p.setRenderHint(QPainter.Antialiasing)
			p.drawEllipse(QPointF(x, y), r, r)

		elif bt=='Marker':
			c2 = QColor(color); c2.setAlpha(140)
			p.setPen(Qt.NoPen); p.setBrush(QBrush(c2))
			p.drawRect(int(x - r), int(y - r), sz, sz)

		elif bt=='Natural Pencil':
			# round() not int() -- int() truncates to 0 for small r, making sz=1..3 look same
			base_alpha = max(25, int(160 * self._brush_hardness / 100))
			count = max(4, sz * sz)
			for _ in range(count):
				angle = random.uniform(0, 2 * math.pi)
				dist  = random.uniform(0, r)
				ox = round(dist * math.cos(angle))
				oy = round(dist * math.sin(angle))
				gs = random.randint(-25, 25)
				c2 = QColor(min(255,max(0,color.red()+gs)), min(255,max(0,color.green()+gs)),
							min(255,max(0,color.blue()+gs)), max(8, base_alpha - random.randint(0, 100)))
				p.setPen(QPen(c2, 1)); p.drawPoint(x + ox, y + oy)

		elif bt=='Crayon':
			# round() not int()
			base_alpha = max(60, int(200 * self._brush_hardness / 100))
			count = max(8, sz * sz * 2)
			for _ in range(count):
				angle = random.uniform(0, 2 * math.pi)
				dist  = random.uniform(0, r)
				ox = round(dist * math.cos(angle))
				oy = round(dist * math.sin(angle))
				c2 = QColor(color); c2.setAlpha(max(20, base_alpha - random.randint(0, 120)))
				p.setPen(QPen(c2, 1)); p.drawPoint(x + ox, y + oy)

		p.end()

	def _draw_brush_line(self, p1, p2, color):
		p1f=QPointF(p1); p2f=QPointF(p2); dx=p2f.x()-p1f.x(); dy=p2f.y()-p1f.y()
		dist=math.hypot(dx,dy)
		if dist<0.5: self._put_brush(QPoint(int(round(p2f.x())),int(round(p2f.y()))),color); return
		bt=self._brush_type
		sz=max(1, self._pen_width)
		if bt in ('Natural Pencil','Crayon'):
			step=max(1.0, sz*0.4)
		elif bt=='Airbrush':
			step=max(2.0, sz*0.5)
		elif bt in ('Oil Brush','Watercolor'):
			step=max(1.0, sz*0.3)
		else:
			step=max(0.5, sz*0.4)
		steps=max(1,int(dist/step))
		for i in range(1,steps+1):
			t=i/steps; self._put_brush(QPoint(int(round(p1f.x()+dx*t)),int(round(p1f.y()+dy*t))),color)

	def _put_eraser(self, pt):
		# Float radius: sz=1->r=0.5, sz=2->r=1.0, sz=3->r=1.5 -- all visibly distinct
		sz=max(1,self._pen_width); r=sz/2.0; p=QPainter(self._image)
		p.setRenderHint(QPainter.Antialiasing, self._brush_shape=='circle')
		alpha=int(255*self._brush_hardness/100)
		if self._show_transparency:
			p.setCompositionMode(QPainter.CompositionMode_DestinationOut); ec=QColor(0,0,0,alpha)
		else:
			p.setCompositionMode(QPainter.CompositionMode_SourceOver); ec=QColor(255,255,255,alpha)
		p.setPen(Qt.NoPen); p.setBrush(QBrush(ec))
		if self._brush_shape=='circle':
			p.drawEllipse(QPointF(pt.x(), pt.y()), r, r)
		else:
			p.drawRect(int(pt.x()-r), int(pt.y()-r), sz, sz)
		p.end(); self.update()

	def _draw_eraser_line(self, p1, p2):
		p1f=QPointF(p1); p2f=QPointF(p2); dx=p2f.x()-p1f.x(); dy=p2f.y()-p1f.y()
		dist=math.hypot(dx,dy)
		if dist<0.5: self._put_eraser(QPoint(int(round(p2f.x())),int(round(p2f.y())))); return
		step=max(0.5,self._pen_width/2.0); steps=max(1,int(dist/step))
		for i in range(1,steps+1):
			t=i/steps; self._put_eraser(QPoint(int(round(p1f.x()+dx*t)),int(round(p1f.y()+dy*t))))

	def _flood_fill(self, pt, color):
		x,y=pt.x(),pt.y()
		w,h=self._image.width(),self._image.height()
		if not (0<=x<w and 0<=y<h): return
		target=self._image.pixel(x,y)
		new_rgb=color.rgba()   # include alpha so comparison matches pixel() return value
		if target==new_rgb: return
		stack=[(x,y)]
		while stack:
			cx,cy=stack.pop()
			if not(0<=cx<w and 0<=cy<h): continue
			if self._image.pixel(cx,cy)!=target: continue
			self._image.setPixel(cx,cy,new_rgb)
			stack+=[(cx+1,cy),(cx-1,cy),(cx,cy+1),(cx,cy-1)]

	# ─── Drag & drop ──────────────────────────────────────────────────────────
	def dragEnterEvent(self, e):
		if e.mimeData().hasUrls(): e.acceptProposedAction()

	def dropEvent(self, e):
		for url in e.mimeData().urls():
			path=url.toLocalFile()
			if path and Path(path).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.gif','.tif','.tiff','.jxl'):
				self.open_file(path); break


# ════════════════════════════════════════════════════════════════════════════════
#  Colour swatch (standard palette swatch)
# ════════════════════════════════════════════════════════════════════════════════
class Swatch(QLabel):
	clicked = pyqtSignal(QColor, bool)
	def __init__(self, color, parent=None):
		super().__init__(parent)
		self._color = QColor(color)
		self.setFixedSize(16,16)
		self.setStyleSheet(f'background:{color};border:1px solid #888;')
		self.setToolTip(color)
	def mousePressEvent(self, e):
		self.clicked.emit(self._color, e.button()==Qt.LeftButton)


# ════════════════════════════════════════════════════════════════════════════════
#  Custom (empty) swatch - double-click to assign color
# ════════════════════════════════════════════════════════════════════════════════
class CustomSwatch(QLabel):
	def __init__(self, idx, main_win, parent=None):
		super().__init__(parent)
		self._idx = idx
		self._main = main_win
		self._color = None
		self.setFixedSize(16,16)
		self.setStyleSheet('background:#e0e0e0;border:1px dashed #aaa;')
		self.setToolTip('Double-click to assign current color')
	def set_color(self, c):
		self._color = c
		self.setStyleSheet(f'background:{c.name()};border:1px solid #888;')
	def mousePressEvent(self, e):
		if self._color:
			active = self._main._color_disp.active
			if active == 'fg':
				self._main.canvas.set_fg(self._color)
				self._main._color_disp.set_fg(self._color)
			else:
				self._main.canvas.set_bg(self._color)
				self._main._color_disp.set_bg(self._color)
	def mouseDoubleClickEvent(self, e):
		# Assign active color to this slot
		active = self._main._color_disp.active
		c = self._main.canvas._fg if active == 'fg' else self._main.canvas._bg
		CUSTOM_PALETTE[self._idx] = c.name()
		self.set_color(c)


# ════════════════════════════════════════════════════════════════════════════════
#  Colour display — Color1 left, Color2 right, with selection indicator
# ════════════════════════════════════════════════════════════════════════════════
class ColorDisplay(QWidget):
	fg_clicked  = pyqtSignal(bool)   # bool = shift held
	bg_clicked  = pyqtSignal(bool)
	def __init__(self, parent=None):
		super().__init__(parent)
		self._fg = QColor(Qt.black)
		self._bg = QColor(Qt.white)
		self._active = 'fg'   # which is currently "selected"
		self.setFixedSize(72, 34)
		self.setToolTip('Left-click to select Color 1 or Color 2\nShift+click to open color picker')
	def set_fg(self, c): self._fg = c; self.update()
	def set_bg(self, c): self._bg = c; self.update()
	@property
	def active(self): return self._active
	def paintEvent(self, e):
		p = QPainter(self)
		# Color 1 box (left)
		bw, bh = 28, 28
		gap = 16   # gap between the two boxes so there's clear space
		x1, x2 = 0, bw + gap
		# highlight active with blue border
		for xi, col, is_active in [(x1, self._fg, self._active=='fg'),
									(x2, self._bg, self._active=='bg')]:
			p.fillRect(xi, 0, bw, bh, col)
			pen = QPen(QColor(0, 120, 215) if is_active else Qt.black,
					   2 if is_active else 1)
			p.setPen(pen)
			p.drawRect(xi, 0, bw-1, bh-1)
		p.end()
	def mousePressEvent(self, e):
		shift = bool(e.modifiers() & Qt.ShiftModifier)
		bw = 28; gap = 16
		if e.x() < bw + gap // 2:
			self._active = 'fg'; self.update(); self.fg_clicked.emit(shift)
		else:
			self._active = 'bg'; self.update(); self.bg_clicked.emit(shift)


# ════════════════════════════════════════════════════════════════════════════════
#  Ribbon group
# ════════════════════════════════════════════════════════════════════════════════
class RibbonGroup(QFrame):
	def __init__(self, title, parent=None):
		super().__init__(parent)
		self.setFrameStyle(QFrame.Box|QFrame.Plain)
		self.setLineWidth(0)
		out=QVBoxLayout(self); out.setContentsMargins(2,2,2,2); out.setSpacing(0)
		self.inner=QWidget()
		self.lay=QHBoxLayout(self.inner); self.lay.setContentsMargins(2,2,2,2); self.lay.setSpacing(2)
		out.addWidget(self.inner)
		lbl=QLabel(title); lbl.setAlignment(Qt.AlignHCenter)
		lbl.setStyleSheet('font-size:8px;color:#555;'); out.addWidget(lbl)
	def add(self, w): self.lay.addWidget(w)
	def add_layout(self, l): self.lay.addLayout(l)


# ════════════════════════════════════════════════════════════════════════════════
#  Main window
# ════════════════════════════════════════════════════════════════════════════════
class ThumbnailWindow(QWidget):
	def __init__(self, canvas, parent=None):
		super().__init__(parent, Qt.Tool|Qt.WindowStaysOnTopHint)
		self.setWindowTitle('Thumbnail'); self._canvas=canvas
		self._lbl=QLabel(); self._lbl.setAlignment(Qt.AlignCenter)
		lay=QVBoxLayout(self); lay.setContentsMargins(4,4,4,4); lay.addWidget(self._lbl)
		self.resize(200,200); self._refresh()
	def _refresh(self):
		img=self._canvas._image; pm=QPixmap.fromImage(img)
		avail=self._lbl.size() if self._lbl.size().isValid() else QSize(192,192)
		self._lbl.setPixmap(pm.scaled(avail,Qt.KeepAspectRatio,Qt.SmoothTransformation))
	def resizeEvent(self,e): super().resizeEvent(e); self._refresh()

class FileThumbnailsWindow(QWidget):
	def __init__(self, folder, parent=None):
		super().__init__(parent, Qt.Tool|Qt.WindowStaysOnTopHint)
		self.setWindowTitle('Thumbnails'); self._folder=folder; self._parent_win=parent
		lay=QVBoxLayout(self); lay.setContentsMargins(4,4,4,4)
		scroll=QScrollArea(); scroll.setWidgetResizable(True)
		inner=QWidget(); self._grid=QGridLayout(inner); self._grid.setSpacing(4)
		scroll.setWidget(inner); lay.addWidget(scroll); self.resize(440,340); self._load()
	def _load(self):
		IMG_EXTS={'.png','.jpg','.jpeg','.bmp','.gif','.tif','.tiff','.jxl'}
		files=sorted(p for p in Path(self._folder).iterdir() if p.is_file() and p.suffix.lower() in IMG_EXTS)
		while self._grid.count():
			item=self._grid.takeAt(0)
			if item.widget(): item.widget().deleteLater()
		cols=5
		for idx,f in enumerate(files):
			pm=QPixmap(str(f))
			if pm.isNull(): continue
			pm=pm.scaled(76,76,Qt.KeepAspectRatio,Qt.SmoothTransformation)
			cell=QVBoxLayout(); cell.setSpacing(2); cell.setAlignment(Qt.AlignHCenter)
			btn=QToolButton(); btn.setIcon(QIcon(pm)); btn.setIconSize(QSize(76,76))
			btn.setFixedSize(80,80); btn.setToolTip(f.name)
			fp=str(f); btn.clicked.connect(lambda _,p=fp: self._open(p))
			lbl=QLabel(); lbl.setAlignment(Qt.AlignHCenter); lbl.setStyleSheet('font-size:9px;')
			lbl.setFixedWidth(80); fm=lbl.fontMetrics()
			lbl.setText(fm.elidedText(f.name,Qt.ElideRight,78)); lbl.setToolTip(f.name)
			cell.addWidget(btn); cell.addWidget(lbl)
			cw=QWidget(); cw.setLayout(cell); self._grid.addWidget(cw,idx//cols,idx%cols)
	def _open(self,path):
		if self._parent_win: self._parent_win._open_path(path)

class MainWindow(QMainWindow):
	def __init__(self, open_path=None):
		super().__init__()
		self.setWindowTitle('Untitled - Clone Paint')
		self.setAcceptDrops(True)
		# Settings location: local ini takes priority.
		# If local ini doesn't exist, check platform config dir (~/.config on Linux,
		# %APPDATA% on Windows). This way portable installs use local file,
		# system installs use the platform config dir.
		local_ini = Path(__file__).parent / 'clone_paint_settings.ini'
		if local_ini.exists():
			settings_path = str(local_ini)
		else:
			# Platform config dir
			if sys.platform == 'win32':
				cfg = Path(os.environ.get('APPDATA', Path.home())) / 'ClonePaint'
			else:
				cfg = Path(os.environ.get('XDG_CONFIG_HOME', Path.home() / '.config')) / 'ClonePaint'
			cfg.mkdir(parents=True, exist_ok=True)
			cfg_ini = cfg / 'clone_paint_settings.ini'
			if cfg_ini.exists():
				settings_path = str(cfg_ini)
			else:
				# Neither exists — use local ini (will be created on first save)
				settings_path = str(local_ini)
		self._settings = QSettings(settings_path, QSettings.IniFormat)
		# Restore window geometry — always restore non-maximized size first
		geom = self._settings.value('window/geometry')
		if geom:
			self.restoreGeometry(geom)
		else:
			self.resize(1200, 760)
		# Then restore maximized state separately so double-click title bar works
		state = self._settings.value('window/state')
		if state:
			self.restoreState(state)

		self.canvas=Canvas()
		self.canvas.cursor_moved.connect(self._on_cursor)
		self.canvas.color_changed.connect(self._on_canvas_color)
		self.canvas.size_changed.connect(self._on_size)
		self.canvas.modified_changed.connect(self._on_modified)
		self.canvas.pixel_picked.connect(self._on_pixel_picked)
		self.canvas.image_changed.connect(self._update_image_stats)
		self._canvas_shown = False

		scroll=QScrollArea(); scroll.setWidget(self.canvas)
		scroll.setWidgetResizable(False); scroll.setStyleSheet('background:#909090;')
		scroll.keyPressEvent = lambda e: self.keyPressEvent(e)
		self.setCentralWidget(scroll)

		self._build_ribbon()
		self._build_menu()
		self._build_statusbar()
		self._load_settings()

		self.setMinimumWidth(300); self.setMinimumHeight(200)

		self._apply_saved_zoom_on_load=False; self._saved_zoom_to_apply=None
		self._beep_on_screenshot = False

		self.canvas.hide(); self.show(); QApplication.processEvents()

		if open_path:
			self.canvas.open_file(open_path)
			if self._apply_saved_zoom_on_load and self._saved_zoom_to_apply:
				self.canvas.set_zoom(self._saved_zoom_to_apply)
			else: self._apply_auto_zoom()
			self._update_imgcount()
		else:
			self.canvas.new_image(400,400)
			if self._apply_saved_zoom_on_load and self._saved_zoom_to_apply:
				self.canvas.set_zoom(self._saved_zoom_to_apply)
			else: self._apply_auto_zoom()

		self.canvas.show(); self._canvas_shown=True; self._update_image_stats()

	def _reveal_canvas(self):
		if not self._canvas_shown:
			self.canvas.show()
			self._canvas_shown = True

	# ─── Menu ─────────────────────────────────────────────────────────────────
	def _build_menu(self):
		# Hide menubar — File button replaces it
		self.menuBar().hide()
		# Register keyboard shortcuts as window actions
		for seq, fn in [
			(QKeySequence.New,   self._new),
			(QKeySequence.Open,  self._open),
			(QKeySequence.Save,  self._save),
			(QKeySequence('Ctrl+Shift+S'), self._save_as),
			(QKeySequence.Undo,  self.canvas.undo),
			(QKeySequence.Redo,  self.canvas.redo),
			(QKeySequence.Cut,   self.canvas.cut_selection),
			(QKeySequence.Copy,  self.canvas.copy_selection),
			(QKeySequence.Paste, self.canvas.paste),
			(QKeySequence('Ctrl+A'), self.canvas.select_all),
			(QKeySequence('Alt+F4'), self.close),
		]:
			a = QAction(self); a.setShortcut(seq); a.triggered.connect(fn)
			self.addAction(a)

	def _build_file_menu(self):
		fm = QMenu(self)
		fm.addAction(get_icon('icon_new'),	'New (&Small Picture)',	 self._new_small)
		fm.addAction(get_icon('icon_new'),	'&New',					self._new)
		fm.addAction(get_icon('icon_open'),   '&Open…',				  self._open)
		fm.addAction(get_icon('icon_delete'), '&Delete',				 self._delete_current_file)
		fm.addSeparator()
		a = fm.addAction(get_icon('icon_save'),   '&Save',			   self._save);   a.setShortcut('Ctrl+S')
		fm.addAction(get_icon('icon_save_as'), 'Save &As…',			   self._save_as)
		
		sam = fm.addMenu(get_icon('icon_save_as'), 'Save As Format')
		# PNG
		act = sam.addAction(get_icon('icon_save_as_png'), 'PNG')
		act.triggered.connect(lambda: self._save_as_fmt('png'))
		# JPEG
		act = sam.addAction(get_icon('icon_save_as_jpeg'), 'JPEG')
		act.triggered.connect(lambda: self._save_as_fmt('jpg'))
		# BMP
		act = sam.addAction(get_icon('icon_save_as_bmp'), 'BMP')
		act.triggered.connect(lambda: self._save_as_fmt('bmp'))
		# GIF
		act = sam.addAction(get_icon('icon_save_as_gif'), 'GIF')
		act.triggered.connect(lambda: self._save_as_fmt('gif'))
		
		act = sam.addAction(get_icon('icon_save_as_png'), 'JPEG XL')
		act.triggered.connect(lambda: self._save_as_fmt('jxl'))	
		
		# sam = fm.addMenu(get_icon('icon_save_as'), 'Save As Format')
		# for fmt, ext in [('PNG','png'),('JPEG','jpg'),('BMP','bmp'),('GIF','gif'),('JPEG XL','jxl')]:
			# sam.addAction(fmt, lambda e=ext: self._save_as_fmt(e))
		fm.addSeparator()
		fm.addAction(get_icon('icon_close_print_preview'), '&Close',				  self._close_image)
		fm.addSeparator()
		fm.addAction(get_icon('icon_save'),   '&Rename',		   self._rename_file).setShortcut('F2')
		fm.addAction(get_icon('icon_open'),   'Re&load',		   self._reload_file).setShortcut('F5')
		fm.addSeparator()
		fm.addAction(get_icon('icon_paste'),  '&Move to folder…',  self._move_file).setShortcut('F7')
		fm.addAction(get_icon('icon_paste'),  'Move to &temp',	 self._move_to_temp).setShortcut('Shift+F7')
		fm.addAction(get_icon('icon_copy'),   'Cop&y to folder…',  self._copy_file).setShortcut('F8')
		fm.addAction(get_icon('icon_copy'),   'Copy to te&mp',	 self._copy_to_temp).setShortcut('Shift+F8')
		fm.addSeparator()
		fm.addAction(get_icon('icon_left_arrow'), 'F&irst file',   self._first_file).setShortcut('Home')
		fm.addAction(get_icon('icon_right_arrow'),'&Last file',	self._last_file).setShortcut('End')
		fm.addSeparator()
		fm.addAction(get_icon('icon_properties'), '&Properties…',  self._properties)
		fm.addAction(get_icon('icon_about'),	  '&About…',		self._about)
		fm.addSeparator()
		fm.addAction(get_icon('icon_exit'),	   'E&xit',		  self.close)
		return fm

	# ─── Ribbon ───────────────────────────────────────────────────────────────
	def _build_ribbon(self):
		# Tab toolbar - MUST be first to be at very top
		# ── Row 1: Quick access toolbar ──
		self._qa_bar=QToolBar('Quick Access')
		self._qa_bar.setMovable(False); self._qa_bar.setObjectName('QABar')
		self._qa_bar.setIconSize(QSize(18,18))
		self.addToolBar(Qt.TopToolBarArea, self._qa_bar)

		self.addToolBarBreak(Qt.TopToolBarArea)

		# ── Row 2: Tab bar — Home | View ... ▲ — always visible ──
		self._tab_bar = QToolBar('Tabs')
		self._tab_bar.setMovable(False); self._tab_bar.setObjectName('TabBar')
		self.addToolBar(Qt.TopToolBarArea, self._tab_bar)

		# File button (left of Home, shows popup menu)
		self._file_btn = QToolButton()
		self._file_btn.setText('File')
		self._file_btn.setAutoRaise(True)
		self._file_btn.setPopupMode(QToolButton.InstantPopup)
		self._tab_bar.addWidget(self._file_btn)

		self._tab_home=QToolButton(); self._tab_home.setText('Home')
		self._tab_home.setCheckable(True); self._tab_home.setChecked(True); self._tab_home.setAutoRaise(True)
		self._tab_view=QToolButton(); self._tab_view.setText('View')
		self._tab_view.setCheckable(True); self._tab_view.setAutoRaise(True)
		self._tab_modify=QToolButton(); self._tab_modify.setText('Modify')
		self._tab_modify.setCheckable(True); self._tab_modify.setAutoRaise(True)
		self._tab_group=QButtonGroup(self)
		self._tab_group.addButton(self._tab_home)
		self._tab_group.addButton(self._tab_view)
		self._tab_group.addButton(self._tab_modify)
		self._tab_group.setExclusive(True)

		self._ribbon_collapsed = False
		self._collapse_btn = QToolButton()
		self._collapse_btn.setText('▲')
		self._collapse_btn.setAutoRaise(True)
		self._collapse_btn.setToolTip('Hide/show toolbar')
		self._collapse_btn.clicked.connect(self._toggle_ribbon)

		# Order: Home | View | Modify | ▲
		self._tab_bar.addWidget(self._tab_home)
		self._tab_bar.addWidget(self._tab_view)
		self._tab_bar.addWidget(self._tab_modify)
		self._tab_bar.addWidget(self._collapse_btn)

		# Double-click on any tab also toggles ribbon
		self._tab_home.mouseDoubleClickEvent   = lambda e: self._toggle_ribbon()
		self._tab_view.mouseDoubleClickEvent   = lambda e: self._toggle_ribbon()
		self._tab_modify.mouseDoubleClickEvent = lambda e: self._toggle_ribbon()

		self.addToolBarBreak(Qt.TopToolBarArea)

		# ── Row 3: Main ribbon toolbar — hidden when collapsed ──
		rt=QToolBar('Ribbon'); rt.setMovable(False); rt.setObjectName('Ribbon')
		self.addToolBar(Qt.TopToolBarArea, rt)

		# Home panel
		self._home_panel=QWidget()
		hl=QHBoxLayout(self._home_panel); hl.setContentsMargins(0,0,0,0); hl.setSpacing(4)

		# Clipboard group
		cg=RibbonGroup('Clipboard')
		clip_lay=QHBoxLayout(); clip_lay.setContentsMargins(0,0,0,0); clip_lay.setSpacing(2)
		clip_lay.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)
		paste_wrap=QVBoxLayout(); paste_wrap.setContentsMargins(0,0,0,0); paste_wrap.setAlignment(Qt.AlignTop)
		paste_b=QToolButton()
		paste_b.setIcon(get_icon('icon_paste',32)); paste_b.setIconSize(QSize(32,32))
		paste_b.setText('Paste'); paste_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		paste_b.setAutoRaise(True); paste_b.setFixedSize(60,60)
		paste_b.clicked.connect(self.canvas.paste)
		pm=QMenu()
		pm.addAction(get_icon('icon_paste'),'Paste',self.canvas.paste)
		pm.addAction(get_icon('icon_paste_from'),'Paste From…',self._paste_from)
		pm.addSeparator()
		
		# pm.addAction(get_icon('icon_screenshot') if get_icon('icon_screenshot') else get_icon('icon_paste'),					 'Screenshot', self._screenshot)
		# pm.addAction(get_icon('icon_screenshot') if get_icon('icon_screenshot') else get_icon('icon_paste'),					 'Screenshot Active Window', self._screenshot_active)
		# pm.addSeparator()
		# pm.addAction(get_icon('icon_screenshot') if get_icon('icon_screenshot') else get_icon('icon_paste'),					 'Screenshot and Paste', self._screenshot_and_paste)
		# pm.addAction(get_icon('icon_screenshot') if get_icon('icon_screenshot') else get_icon('icon_paste'),					 'Screenshot Active Window and Paste', self._screenshot_active_and_paste)
					 
		pm.addAction(get_icon('icon_set_as_desktop_background_center'), 'Screenshot', self._screenshot)
		pm.addAction(get_icon('icon_set_as_desktop_background_center'), 'Screenshot Active Window', self._screenshot_active)
		pm.addSeparator()
		pm.addAction(get_icon('icon_set_as_desktop_background_center'), 'Screenshot and Paste', self._screenshot_and_paste)
		pm.addAction(get_icon('icon_set_as_desktop_background_center'), 'Screenshot Active Window and Paste', self._screenshot_active_and_paste)					 
					 
					 
		paste_b.setMenu(pm); paste_b.setPopupMode(QToolButton.MenuButtonPopup)
		paste_wrap.addWidget(paste_b); paste_wrap.addStretch()
		clip_lay.addLayout(paste_wrap)
		cc=QVBoxLayout(); cc.setContentsMargins(0,0,0,0)
		for icon_n,label,fn in [('icon_cut','Cut',self.canvas.cut_selection),('icon_copy','Copy',self.canvas.copy_selection)]:
			b=QToolButton(); b.setIcon(get_icon(icon_n)); b.setIconSize(QSize(18,18))
			b.setText(f' {label}'); b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
			b.setAutoRaise(True); b.setFixedWidth(65); b.clicked.connect(fn); cc.addWidget(b)
		clip_lay.addLayout(cc)
		cg.add_layout(clip_lay); hl.addWidget(cg)

		# Image group — Select (large, like Paste) + Crop/Resize/Rotate stacked beside it
		ig=RibbonGroup('Image')
		img_lay=QHBoxLayout(); img_lay.setContentsMargins(0,0,0,0); img_lay.setSpacing(2)
		img_lay.setAlignment(Qt.AlignLeft|Qt.AlignVCenter)

		# _tool_bg created here so sel_b can join it before Tools group is built
		self._tool_bg=QButtonGroup(self); self._tool_bg.setExclusive(True)

		sel_wrap=QVBoxLayout(); sel_wrap.setContentsMargins(0,0,0,0); sel_wrap.setAlignment(Qt.AlignTop)

		# Select button — checkable, joins _tool_bg, remembers last chosen subtype
		sel_b=QToolButton(); sel_b.setIcon(get_icon('icon_select',32)); sel_b.setIconSize(QSize(32,32))
		sel_b.setText('Select'); sel_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		sel_b.setCheckable(True); sel_b.setAutoRaise(True); sel_b.setFixedSize(60,60)
		sel_b._cp_tool = 'selectrect'
		self._tool_bg.addButton(sel_b)
		self._sel_last_tool='selectrect'; self._sel_last_icon='icon_select'
		def _sel_click():
			self.canvas.set_tool(self._sel_last_tool)
		sel_b.clicked.connect(_sel_click)
		sm=QMenu()
		def _sel_action(icon_n, label, tool):
			def _do():
				self._sel_last_tool=tool; self._sel_last_icon=icon_n
				sel_b.setChecked(True)
				sel_b.setIcon(get_icon(icon_n,32)); sel_b.setIconSize(QSize(32,32))
				self.canvas.set_tool(tool)
			sm.addAction(get_icon(icon_n), label, _do)
		_sel_action('icon_select','Rectangular selection','selectrect')
		_sel_action('icon_free_form_selection',  'Free-form selection',  'select')
		sm.addSeparator(); hdr=sm.addAction('Selection options'); hdr.setEnabled(False); sm.addSeparator()
		sm.addAction(get_icon('icon_select_all'),   'Select all',	   self.canvas.select_all)
		sm.addAction(get_icon('icon_invert_selection'),'Invert selection', lambda: None)
		sm.addAction(get_icon('icon_delete'),	  'Delete',		   self.canvas.delete_selection)
		sm.addSeparator()
		sm.addAction(get_icon('icon_transparent_selection'), 'Transparent selection', lambda: None)
		sel_b.setMenu(sm); sel_b.setPopupMode(QToolButton.MenuButtonPopup)
		sel_wrap.addWidget(sel_b); sel_wrap.addStretch(); img_lay.addLayout(sel_wrap)

		# Crop, Resize, Rotate stacked vertically
		c1=QVBoxLayout()
		crop_b=QToolButton(); crop_b.setIcon(get_icon('icon_crop')); crop_b.setIconSize(QSize(18,18))
		crop_b.setText(' Crop'); crop_b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
		crop_b.setAutoRaise(True); crop_b.clicked.connect(self.canvas.crop_to_selection); c1.addWidget(crop_b)
		resize_b=QToolButton(); resize_b.setIcon(get_icon('icon_resize')); resize_b.setIconSize(QSize(18,18))
		resize_b.setText(' Resize'); resize_b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
		resize_b.setAutoRaise(True); resize_b.clicked.connect(self._resize_dialog); c1.addWidget(resize_b)
		rot_b=QToolButton(); rot_b.setIcon(get_icon('icon_rotate')); rot_b.setIconSize(QSize(18,18))
		rot_b.setText(' Rotate▼'); rot_b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
		rot_b.setAutoRaise(True); rot_b.setPopupMode(QToolButton.InstantPopup)
		rm=QMenu()
		def _rot_action(ic, lbl, fn):
			def _do(): rot_b.setIcon(get_icon(ic)); rot_b.setIconSize(QSize(18,18)); fn()
			rm.addAction(get_icon(ic), lbl, _do)
		_rot_action('icon_rotate_right_90',   'Rotate right 90°', lambda: self.canvas.rotate(90))
		_rot_action('icon_rotate_left_90',	'Rotate left 90°',  lambda: self.canvas.rotate(-90))
		_rot_action('icon_rotate_180',	 'Rotate 180°',	  lambda: self.canvas.rotate(180))
		_rot_action('icon_flip_vertical',  'Flip vertical',	lambda: self.canvas.flip(False))
		_rot_action('icon_flip_horizontal','Flip horizontal',  lambda: self.canvas.flip(True))
		rm.addSeparator(); _rot_action('icon_outline','Custom…', self._rotate_custom)
		rot_b.setMenu(rm); c1.addWidget(rot_b)
		img_lay.addLayout(c1); ig.add_layout(img_lay); hl.addWidget(ig)

		# Tools group
		tgrp=RibbonGroup('Tools'); tgrid=QGridLayout(); tgrid.setSpacing(1)
		tool_rows=[
			[('icon_pencil','pencil','Pencil'),('icon_fill','fill','Fill'),('icon_text','text','Text')],
			[('icon_eraser','eraser','Eraser'),('icon_color_picker','picker','Color Picker'),('icon_magnifier','magnifier','Magnifier')],
		]
		for r,row in enumerate(tool_rows):
			for c,(icon_n,t_n,hint) in enumerate(row):
				b=QToolButton(); ico=get_icon(icon_n)
				if not ico.isNull(): b.setIcon(ico); b.setIconSize(QSize(22,22))
				else: b.setText(hint[0])
				b.setToolTip(hint); b.setCheckable(True); b.setAutoRaise(True); b.setFixedSize(30,26)
				b._cp_tool = t_n   # tag for tool_changed lookup
				b.clicked.connect(lambda chk=False,t=t_n: self.canvas.set_tool(t))
				self._tool_bg.addButton(b); tgrid.addWidget(b,r,c)
		tgrp.add_layout(tgrid); hl.addWidget(tgrp)

		# Brushes group — checkable, joins _tool_bg, remembers last type, wider for text
		bgrp=RibbonGroup('Brushes')
		bb=QToolButton(); bb.setIcon(get_icon('icon_brush',28)); bb.setIconSize(QSize(28,28))
		bb.setText('Brushes'); bb.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		bb.setCheckable(True); bb.setAutoRaise(True); bb.setFixedSize(72,60)
		bb._cp_tool = 'brush'
		bb.setPopupMode(QToolButton.MenuButtonPopup)
		self._tool_bg.addButton(bb)
		self._brush_last_type='Normal'; self._brush_last_icon='icon_brush'
		def _brush_click():
			self.canvas.set_tool('brush'); self.canvas.set_brush_type(self._brush_last_type)
		bb.clicked.connect(_brush_click)
		brm=QMenu()
		for _ic,_nm in BRUSH_TYPES:
			def _mk_brush(ic,nm):
				def _do():
					self._brush_last_type=nm; self._brush_last_icon=ic
					bb.setChecked(True)
					bb.setIcon(get_icon(ic,28)); bb.setIconSize(QSize(28,28))
					self.canvas.set_tool('brush'); self.canvas.set_brush_type(nm)
				brm.addAction(get_icon(ic),nm,_do)
			_mk_brush(_ic,_nm)
		bb.setMenu(brm); bgrp.add(bb); hl.addWidget(bgrp)

		# Wire tool_changed → update _tool_bg checkmarks
		# Build a map from tool-name → button
		_tool_btn_map = {}
		for btn in self._tool_bg.buttons():
			# Each button's click lambda captures a tool name; we extract it from the connection
			pass  # we'll do it by keeping references below

		self._sel_b = sel_b
		self._bb = bb
		def _on_tool_changed(tool):
			# sel_b covers both selectrect and select (free-form)
			target_tool = 'selectrect' if tool in ('selectrect','select') else tool
			self._tool_bg.setExclusive(False)
			for b in self._tool_bg.buttons():
				b.setChecked(getattr(b,'_cp_tool',None) == target_tool)
			self._tool_bg.setExclusive(True)
		self.canvas.tool_changed.connect(_on_tool_changed)

		# Shapes group (7 cols + outline/fill)
		sgrp=RibbonGroup('Shapes')
		souter=QHBoxLayout()
		sgrid=QGridLayout(); sgrid.setSpacing(1)
		self._shape_bg=QButtonGroup(self); self._shape_bg.setExclusive(True)
		COLS=7
		for idx,(icon_n,sh_n,hint) in enumerate(SHAPES):
			b=QToolButton(); ico=get_icon(icon_n)
			if not ico.isNull(): b.setIcon(ico); b.setIconSize(QSize(20,20))
			else: b.setText(hint[:2])
			b.setToolTip(hint); b.setCheckable(True); b.setAutoRaise(True); b.setFixedSize(26,22)
			b.clicked.connect(lambda chk=False,s=sh_n: self.canvas.set_shape(s))
			self._shape_bg.addButton(b); sgrid.addWidget(b, idx//COLS, idx%COLS)
		souter.addLayout(sgrid)

		# Outline + Fill dropdowns
		of_col=QVBoxLayout(); of_col.setSpacing(2)
		ol_b=QToolButton(); ol_b.setIcon(get_icon('icon_outline')); ol_b.setIconSize(QSize(18,18))
		ol_b.setText('Outline▼'); ol_b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
		ol_b.setAutoRaise(True); ol_b.setPopupMode(QToolButton.InstantPopup)
		olm=QMenu()
		def _ol_action(ic,lbl,fn):
			def _do(): ol_b.setIcon(get_icon(ic)); ol_b.setIconSize(QSize(18,18)); fn()
			olm.addAction(get_icon(ic),lbl,_do)
		_ol_action('icon_no_outline', 'No outline',	lambda: self.canvas.set_shape_outline(0))
		_ol_action('icon_solid_color_fill','Solid color',   lambda: self.canvas.set_shape_outline(1))
		_ol_action('icon_crayon',	'Crayon',		lambda: None)
		_ol_action('icon_marker',	'Marker',		lambda: None)
		_ol_action('icon_oil_brush',  'Oil',		   lambda: None)
		_ol_action('icon_pencil',	'Natural pencil',lambda: None)
		_ol_action('icon_watercolor_brush','Watercolor',	lambda: None)
		ol_b.setMenu(olm)

		fi_b=QToolButton(); fi_b.setIcon(get_icon('icon_fill')); fi_b.setIconSize(QSize(18,18))
		fi_b.setText('Fill▼'); fi_b.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
		fi_b.setAutoRaise(True); fi_b.setPopupMode(QToolButton.InstantPopup)
		fim=QMenu()
		def _fi_action(ic,lbl,fn):
			def _do(): fi_b.setIcon(get_icon(ic)); fi_b.setIconSize(QSize(18,18)); fn()
			fim.addAction(get_icon(ic),lbl,_do)
		_fi_action('icon_no_outline', 'No fill',	   lambda: self.canvas.set_shape_fill(0))
		_fi_action('icon_solid_color_fill','Solid color',   lambda: self.canvas.set_shape_fill(1))
		_fi_action('icon_crayon',	'Crayon',		lambda: None)
		_fi_action('icon_marker',	'Marker',		lambda: None)
		_fi_action('icon_oil_brush',  'Oil',		   lambda: None)
		_fi_action('icon_pencil',	'Natural pencil',lambda: None)
		_fi_action('icon_watercolor_brush','Watercolor',	lambda: None)
		fi_b.setMenu(fim)

		of_col.addWidget(ol_b); of_col.addWidget(fi_b)
		souter.addLayout(of_col)
		sgrp.add_layout(souter); hl.addWidget(sgrp)

		# Size group
		szgrp=RibbonGroup('Size')
		sz_col=QVBoxLayout()
		self._sz_b=QToolButton(); self._sz_b.setIcon(get_icon('icon_3px_size')); self._sz_b.setIconSize(QSize(20,20))
		self._sz_b.setText('3 px▼'); self._sz_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		self._sz_b.setAutoRaise(True); self._sz_b.setPopupMode(QToolButton.InstantPopup)
		szm=QMenu()
		def _set_size(s, lbl, ic):
			self.canvas.set_pen_width(s)
			self._sz_b.setIcon(get_icon(ic)); self._sz_b.setIconSize(QSize(20,20))
			self._sz_b.setText(f'{lbl}▼')
			if hasattr(self,'_mod_brush_width'):
				self._mod_brush_width.blockSignals(True)
				self._mod_brush_width.setValue(s)
				self._mod_brush_width.blockSignals(False)
		for sw,slabel,sicon in [(1,'1 px','1px_size'),(3,'3 px','3px_size'),(5,'5 px','5px_size'),(8,'8 px','8px_size')]:
			def _mk(s,lbl,ic):
				szm.addAction(get_icon(ic),lbl,lambda s=s,lbl=lbl,ic=ic: _set_size(s,lbl,ic))
			_mk(sw,slabel,sicon)
		def _custom_size():
			v,ok=QInputDialog.getInt(self,'Custom Width','Enter brush width (1–500):',
									 self.canvas._pen_width,1,500)
			if ok:
				self.canvas.set_pen_width(v)
				self._sz_b.setIcon(get_icon('icon_size')); self._sz_b.setIconSize(QSize(20,20))
				self._sz_b.setText('Custom▼')
				if hasattr(self,'_mod_brush_width'):
					self._mod_brush_width.blockSignals(True)
					self._mod_brush_width.setValue(v)
					self._mod_brush_width.blockSignals(False)
		szm.addSeparator(); szm.addAction('Custom…',_custom_size)
		self._sz_b.setMenu(szm); sz_col.addWidget(self._sz_b)
		szgrp.add_layout(sz_col); hl.addWidget(szgrp)

		# Add spacing between Size and Colors
		hl.addSpacing(8)

		# Colors group
		clgrp=RibbonGroup('Colors')
		cl=QHBoxLayout()
		# Color display + labels (Color 1 and Color 2 side by side above)
		cc2=QVBoxLayout()
		lbl_row=QHBoxLayout(); lbl_row.setSpacing(16)
		lbl1=QLabel('Color 1'); lbl1.setStyleSheet('font-size:8px;')
		lbl2=QLabel('Color 2'); lbl2.setStyleSheet('font-size:8px;')
		lbl_row.addWidget(lbl1); lbl_row.addWidget(lbl2)
		cc2.addLayout(lbl_row)
		self._color_disp=ColorDisplay()
		self._color_disp.fg_clicked.connect(self._choose_fg)
		self._color_disp.bg_clicked.connect(self._choose_bg)
		cc2.addWidget(self._color_disp)
		cl.addLayout(cc2)
		# spacing between color boxes and palette
		cl.addSpacing(8)
		# Swatches: 2 rows of 10 palette colors + 1 row of 10 custom empty slots
		self._sw_col=QVBoxLayout(); self._sw_col.setSpacing(1)
		row1=QHBoxLayout(); row1.setSpacing(1)
		row2=QHBoxLayout(); row2.setSpacing(1)
		row3=QHBoxLayout(); row3.setSpacing(1)
		self._swatch_widgets=[]
		for i,color in enumerate(PALETTE):
			sw=Swatch(color); sw.clicked.connect(self._on_swatch)
			(row1 if i<10 else row2).addWidget(sw)
			self._swatch_widgets.append(sw)
		# Third row: 10 custom/empty slots
		self._custom_sw=[]
		for i in range(10):
			sw=CustomSwatch(i,self); row3.addWidget(sw)
			self._custom_sw.append(sw)
		self._sw_col.addLayout(row1)
		self._sw_col.addLayout(row2)
		self._sw_col.addLayout(row3)
		cl.addLayout(self._sw_col)
		# spacing between palette and Edit colors
		cl.addSpacing(8)
		# Edit colors button
		ec=QToolButton(); ec.setIcon(get_icon('icon_edit_colors')); ec.setIconSize(QSize(20,20))
		ec.setText('Edit\ncolors'); ec.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		ec.setAutoRaise(True); ec.clicked.connect(self._edit_colors); cl.addWidget(ec)
		clgrp.add_layout(cl); hl.addWidget(clgrp)
		hl.addStretch()
		rt.addWidget(self._home_panel)

		# View panel
		self._view_panel=QWidget()
		vl=QHBoxLayout(self._view_panel); vl.setContentsMargins(0,0,0,0); vl.setSpacing(4)

		# Zoom group
		zgrp=RibbonGroup('Zoom')
		zin_b=QToolButton(); zin_b.setIcon(get_icon('icon_zoom_in')); zin_b.setIconSize(QSize(24,24))
		zin_b.setText('Zoom\nin'); zin_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		zin_b.setAutoRaise(True); zin_b.clicked.connect(lambda: self.canvas.set_zoom(round(min(16.0, self.canvas.zoom+0.1),2)))
		zout_b=QToolButton(); zout_b.setIcon(get_icon('icon_zoom_out')); zout_b.setIconSize(QSize(24,24))
		zout_b.setText('Zoom\nout'); zout_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		zout_b.setAutoRaise(True); zout_b.clicked.connect(lambda: self.canvas.set_zoom(round(max(0.1, self.canvas.zoom-0.1),2)))
		z100_b=QToolButton(); z100_b.setIcon(get_icon('icon_100_percent')); z100_b.setIconSize(QSize(24,24))
		z100_b.setText('100%'); z100_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		z100_b.setAutoRaise(True); z100_b.clicked.connect(lambda: self.canvas.set_zoom(1.0))
		zgrp.add(zin_b); zgrp.add(zout_b); zgrp.add(z100_b)
		vl.addWidget(zgrp)

		# Show or hide group
		shgrp=RibbonGroup('Show or hide')
		sh_col=QVBoxLayout(); sh_col.setAlignment(Qt.AlignLeft)
		self._chk_rulers=QCheckBox('Rulers')
		self._chk_gridlines=QCheckBox('Gridlines')
		self._chk_statusbar=QCheckBox('Status bar'); self._chk_statusbar.setChecked(True)
		self._chk_beep=QCheckBox('Beep on screenshot')
		self._chk_rulers.toggled.connect(lambda v:(setattr(self.canvas,'_show_rulers',v),self.canvas.update(),self._save_settings()))
		self._chk_gridlines.toggled.connect(lambda v:(setattr(self.canvas,'_show_gridlines',v),self.canvas.update(),self._save_settings()))
		self._chk_statusbar.toggled.connect(self._toggle_sb)
		self._chk_beep.toggled.connect(lambda v:(setattr(self,'_beep_on_screenshot',v),self._save_settings()))
		for chk in (self._chk_rulers,self._chk_gridlines,self._chk_statusbar,self._chk_beep):
			chk.setStyleSheet('font-size:10px;'); sh_col.addWidget(chk)
		shgrp.add_layout(sh_col); vl.addWidget(shgrp)

		# Display group
		dgrp=RibbonGroup('Display')
		fs_b=QToolButton(); fs_b.setIcon(get_icon('icon_full_screen')); fs_b.setIconSize(QSize(24,24))
		fs_b.setText('Full\nscreen'); fs_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		fs_b.setAutoRaise(True)
		fs_b.clicked.connect(lambda: self.setWindowState(self.windowState()^Qt.WindowFullScreen))
		th_b=QToolButton(); th_b.setIcon(get_icon('icon_thumbnail')); th_b.setIconSize(QSize(24,24))
		th_b.setText('Thumb\nnail'); th_b.setToolButtonStyle(Qt.ToolButtonTextUnderIcon)
		th_b.setAutoRaise(True); th_b.setPopupMode(QToolButton.MenuButtonPopup)
		thm=QMenu()
		self._thumb_win=None; self._file_thumb_win=None
		def _show_thumbnail():
			if self._thumb_win and self._thumb_win.isVisible(): self._thumb_win.hide(); return
			if not self._thumb_win: self._thumb_win=ThumbnailWindow(self.canvas,self)
			self._thumb_win._refresh(); self._thumb_win.show()
		def _show_file_thumbnails():
			folder=self._default_dir()
			if self._file_thumb_win: self._file_thumb_win.close()
			self._file_thumb_win=FileThumbnailsWindow(folder,self); self._file_thumb_win.show()
		thm.addAction('Thumbnail',_show_thumbnail); thm.addAction('Thumbnails',_show_file_thumbnails)
		th_b.setMenu(thm); th_b.clicked.connect(_show_thumbnail)
		from PyQt5.QtWidgets import QShortcut
		from PyQt5.QtGui import QKeySequence
		QShortcut(QKeySequence('Ctrl+T'),self,_show_file_thumbnails)
		_orig_update=self.canvas.update
		def _patched_update(*a,**kw):
			_orig_update(*a,**kw)
			if self._thumb_win and self._thumb_win.isVisible(): self._thumb_win._refresh()
		self.canvas.update=_patched_update
		dgrp.add(fs_b); dgrp.add(th_b); vl.addWidget(dgrp)

		# Settings group — 2 columns to keep toolbar shorter
		stgrp=RibbonGroup('Settings')
		st_row=QHBoxLayout()
		# Column 1
		col1=QVBoxLayout(); col1.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		self._chk_transp=QCheckBox('Show transparency'); self._chk_transp.setChecked(True)
		self._chk_autosave=QCheckBox('Auto save PNG, BMP on changes')
		self._chk_maxpng=QCheckBox('Use max PNG compression')
		self._chk_transp.toggled.connect(lambda v:(self.canvas.set_show_transparency(v),self._save_settings()))
		self._chk_autosave.toggled.connect(lambda v:(setattr(self.canvas,'_auto_save_lossless',v),self._update_autosave_label(),self._save_settings()))
		self._chk_maxpng.toggled.connect(lambda v:(setattr(self.canvas,'_max_png_compression',v),self._save_settings()))
		for chk in (self._chk_transp, self._chk_autosave, self._chk_maxpng):
			chk.setStyleSheet('font-size:10px;'); col1.addWidget(chk)
		# Column 2
		col2=QVBoxLayout(); col2.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		self._chk_zoom_big=QCheckBox('Zoom out big images'); self._chk_zoom_big.setChecked(True)
		self._chk_zoom_small=QCheckBox('Zoom in small images')
		self._chk_zoom_big.toggled.connect(lambda v: self._save_settings())
		self._chk_zoom_small.toggled.connect(lambda v: self._save_settings())
		reset_btn = QPushButton('Reset colors'); reset_btn.setStyleSheet('font-size:10px;')
		reset_btn.clicked.connect(self._reset_palette)
		for chk in (self._chk_zoom_big, self._chk_zoom_small):
			chk.setStyleSheet('font-size:10px;'); col2.addWidget(chk)
		col2.addWidget(reset_btn)
		st_row.addLayout(col1); st_row.addSpacing(8); st_row.addLayout(col2)
		# Column 3
		col3=QVBoxLayout(); col3.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		self._chk_start_select=QCheckBox('On start use select')
		self._chk_start_select.toggled.connect(lambda v: self._save_settings())
		self._chk_start_select.setStyleSheet('font-size:10px;'); col3.addWidget(self._chk_start_select)
		self._chk_recycle=QCheckBox('Delete to recycle bin')
		self._chk_recycle.setChecked(True)
		self._chk_recycle.toggled.connect(lambda v: self._save_settings())
		self._chk_recycle.setStyleSheet('font-size:10px;'); col3.addWidget(self._chk_recycle)
		self._chk_del_noconfirm=QCheckBox('Del without confirm')
		self._chk_del_noconfirm.toggled.connect(lambda v: (self._update_delconfirm_label(), self._save_settings()))
		self._chk_del_noconfirm.setStyleSheet('font-size:10px;'); col3.addWidget(self._chk_del_noconfirm)
		self._chk_pinch_stretch=QCheckBox('Pinch to stretch (not crop)')
		self._chk_pinch_stretch.setChecked(False)
		self._chk_pinch_stretch.toggled.connect(lambda v: (setattr(self.canvas,'_pinch_stretch',v),self._save_settings()))
		self._chk_pinch_stretch.setStyleSheet('font-size:10px;'); col3.addWidget(self._chk_pinch_stretch)
		st_row.addSpacing(8); st_row.addLayout(col3)
		stgrp.add_layout(st_row); vl.addWidget(stgrp)

		vl.addStretch()
		self._view_panel.setVisible(True)

		# ── Modify panel ──────────────────────────────────────────────────────
		self._modify_panel = QWidget()
		ml = QHBoxLayout(self._modify_panel)
		ml.setContentsMargins(0, 0, 0, 0); ml.setSpacing(4)

		# Brush Settings group
		bsgrp = RibbonGroup('Brush Settings')
		bsgrp.setMaximumWidth(180)
		bs_col = QVBoxLayout(); bs_col.setSpacing(3); bs_col.setAlignment(Qt.AlignLeft|Qt.AlignTop)

		# Width row
		bw_row = QHBoxLayout(); bw_row.setSpacing(4)
		bw_row.addWidget(QLabel('Width:'))
		self._mod_brush_width = QSpinBox(); self._mod_brush_width.setRange(1, 500)
		self._mod_brush_width.setValue(self.canvas._pen_width); self._mod_brush_width.setFixedWidth(52)
		def _on_mod_width(v):
			self.canvas.set_pen_width(v)
			if hasattr(self, '_sz_b'):
				self._sz_b.setIcon(get_icon('icon_size')); self._sz_b.setIconSize(QSize(20, 20))
				self._sz_b.setText('Custom▼')
		self._mod_brush_width.valueChanged.connect(_on_mod_width)
		bw_row.addWidget(self._mod_brush_width); bw_row.addStretch()
		bs_col.addLayout(bw_row)

		# Shape row
		bshape_row = QHBoxLayout(); bshape_row.setSpacing(4)
		bshape_row.addWidget(QLabel('Shape:'))
		bshape_combo = QComboBox(); bshape_combo.addItems(['Circle', 'Square'])
		bshape_combo.setFixedWidth(72)
		bshape_combo.currentTextChanged.connect(lambda t: self.canvas.set_brush_shape(t.lower()))
		bshape_row.addWidget(bshape_combo); bshape_row.addStretch()
		bs_col.addLayout(bshape_row)

		# Hardness row
		bhard_row = QHBoxLayout(); bhard_row.setSpacing(4)
		bhard_row.addWidget(QLabel('Hardness:'))
		self._mod_hardness = QSlider(Qt.Horizontal); self._mod_hardness.setRange(1, 100)
		self._mod_hardness.setValue(100); self._mod_hardness.setFixedWidth(80)
		self._mod_hard_lbl = QLabel('100%'); self._mod_hard_lbl.setStyleSheet('font-size:10px;')
		self._mod_hardness.valueChanged.connect(
			lambda v: (self.canvas.set_brush_hardness(v), self._mod_hard_lbl.setText(f'{v}%')))
		bhard_row.addWidget(self._mod_hardness); bhard_row.addWidget(self._mod_hard_lbl); bhard_row.addStretch()
		bs_col.addLayout(bhard_row)

		bsgrp.add_layout(bs_col); ml.addWidget(bsgrp)

		# Colors group
		clrgrp = RibbonGroup('Colors')
		clr_col = QVBoxLayout(); clr_col.setSpacing(3); clr_col.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		colors_btn = QPushButton('Colors…')
		colors_btn.setToolTip('Set number of colours (quantise or expand)')
		colors_btn.clicked.connect(self._mod_set_colors)
		gray_btn = QPushButton('Convert to Grayscale')
		gray_btn.clicked.connect(self.canvas.convert_grayscale)
		bw_btn = QPushButton('Convert to B&W…')
		bw_btn.setToolTip('Black & white with adjustable threshold')
		bw_btn.clicked.connect(self._mod_bw)
		for b in (colors_btn, gray_btn, bw_btn):
			b.setStyleSheet('font-size:10px;'); clr_col.addWidget(b)
		clrgrp.add_layout(clr_col); ml.addWidget(clrgrp)

		# Adjustments group
		adjgrp = RibbonGroup('Adjustments')
		adj_col = QVBoxLayout(); adj_col.setSpacing(3); adj_col.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		bright_btn = QPushButton('Brightness…')
		gamma_btn  = QPushButton('Gamma…')
		contr_btn  = QPushButton('Contrast…')
		bright_btn.clicked.connect(self._mod_brightness)
		gamma_btn.clicked.connect(self._mod_gamma)
		contr_btn.clicked.connect(self._mod_contrast)
		for b in (bright_btn, gamma_btn, contr_btn):
			b.setStyleSheet('font-size:10px;'); adj_col.addWidget(b)
		adjgrp.add_layout(adj_col); ml.addWidget(adjgrp)

		# Filters group
		filtgrp = RibbonGroup('Filters')
		filt_col = QVBoxLayout(); filt_col.setSpacing(3); filt_col.setAlignment(Qt.AlignLeft|Qt.AlignTop)
		sharp_btn = QPushButton('Sharpen')
		blur_btn  = QPushButton('Blur')
		sharp_btn.clicked.connect(self.canvas.sharpen)
		blur_btn.clicked.connect(self.canvas.blur)
		for b in (sharp_btn, blur_btn):
			b.setStyleSheet('font-size:10px;'); filt_col.addWidget(b)
		filtgrp.add_layout(filt_col); ml.addWidget(filtgrp)

		ml.addStretch()

		# Use a stacked widget so Home / View / Modify panels properly replace each other
		self._ribbon_stack = QStackedWidget()
		self._ribbon_stack.addWidget(self._home_panel)	# index 0
		self._ribbon_stack.addWidget(self._view_panel)	# index 1
		self._ribbon_stack.addWidget(self._modify_panel)  # index 2
		self._ribbon_stack.setCurrentIndex(0)
		rt.addWidget(self._ribbon_stack)

		# Tab switching — also unhide ribbon if collapsed
		self._tab_home.clicked.connect(self._on_tab_home)
		self._tab_view.clicked.connect(self._on_tab_view)
		self._tab_modify.clicked.connect(self._on_tab_modify)

		# Now safe to populate QA bar and File menu
		self._rebuild_qa()
		self._file_btn.setMenu(self._build_file_menu())

	# ─── Quick access toolbar ─────────────────────────────────────────────────
	def _save_palette(self):
		s = self._settings
		s.setValue('palette/colors', PALETTE)
		s.setValue('palette/custom', CUSTOM_PALETTE)

	def _load_palette(self):
		s = self._settings
		saved = s.value('palette/colors', None)
		if saved and len(saved) == len(PALETTE):
			for i, c in enumerate(saved): PALETTE[i] = c
		custom = s.value('palette/custom', None)
		if custom and len(custom) == len(CUSTOM_PALETTE):
			for i, c in enumerate(custom): CUSTOM_PALETTE[i] = c

	def _reset_palette(self):
		for i, c in enumerate(DEFAULT_PALETTE): PALETTE[i] = c
		for i in range(len(CUSTOM_PALETTE)): CUSTOM_PALETTE[i] = ''
		self._rebuild_swatches()
		for i, sw in enumerate(self._custom_sw):
			sw._color = None
			sw.setStyleSheet('background:#e0e0e0;border:1px dashed #aaa;')
		self._save_palette()

	def _on_tab_home(self):
		if self._ribbon_collapsed:
			self._ribbon_collapsed = False
			for tb in self.findChildren(QToolBar):
				if tb.objectName() == 'Ribbon': tb.setVisible(True)
			self._collapse_btn.setText('▲')
			if hasattr(self, '_qa_toggle_btn'): self._qa_toggle_btn.setText('▲')
		self._ribbon_stack.setCurrentIndex(0)
		self._settings.setValue('view/active_tab', 0); self._settings.sync()

	def _on_tab_view(self):
		if self._ribbon_collapsed:
			self._ribbon_collapsed = False
			for tb in self.findChildren(QToolBar):
				if tb.objectName() == 'Ribbon': tb.setVisible(True)
			self._collapse_btn.setText('▲')
			if hasattr(self, '_qa_toggle_btn'): self._qa_toggle_btn.setText('▲')
		self._ribbon_stack.setCurrentIndex(1)
		self._settings.setValue('view/active_tab', 1); self._settings.sync()

	def _on_tab_modify(self):
		if self._ribbon_collapsed:
			self._ribbon_collapsed = False
			for tb in self.findChildren(QToolBar):
				if tb.objectName() == 'Ribbon': tb.setVisible(True)
			self._collapse_btn.setText('▲')
			if hasattr(self, '_qa_toggle_btn'): self._qa_toggle_btn.setText('▲')
		self._ribbon_stack.setCurrentIndex(2)
		self._settings.setValue('view/active_tab', 2); self._settings.sync()

	# ─── Modify tab actions ───────────────────────────────────────────────────

	def _mod_set_colors(self):
		"""Pick a target colour count from a preset list and quantise (or no-op if expanding)."""
		# Presets: powers of 2 that are meaningful palette sizes
		presets = [2, 4, 8, 16, 32, 64, 128, 256]
		_, cur_label = self.canvas.color_depth_info()
		dlg = QDialog(self)
		dlg.setWindowTitle('Set Number of Colors')
		lay = QVBoxLayout(dlg)
		lay.addWidget(QLabel(f'Current depth: {cur_label}\nSelect target colour count:'))
		combo = QComboBox()
		custom_label = 'Custom…'
		for p in presets:
			combo.addItem(str(p))
		combo.addItem(custom_label)
		combo.setCurrentIndex(3)   # default: 16
		lay.addWidget(combo)
		btns = QHBoxLayout()
		ok = QPushButton('OK');	 ok.clicked.connect(dlg.accept)
		ca = QPushButton('Cancel'); ca.clicked.connect(dlg.reject)
		btns.addWidget(ok); btns.addWidget(ca); lay.addLayout(btns)
		if dlg.exec_() != QDialog.Accepted:
			return
		text = combo.currentText()
		if text == custom_label:
			target, ok2 = QInputDialog.getInt(
				self, 'Custom Color Count', 'Enter number of colours (2–256):', 64, 2, 256)
			if not ok2:
				return
		else:
			target = int(text)
		self.canvas.reduce_colors(target)
		self._update_image_stats()

	def _mod_bw(self):
		thr, ok = QInputDialog.getInt(
			self, 'Black & White',
			'Luminance threshold (0–255).\n'
			'Pixels above → white, at or below → black:', 128, 0, 255)
		if ok:
			self.canvas.convert_black_white(thr)
			self._update_image_stats()

	def _mod_brightness(self):
		delta, ok = QInputDialog.getInt(
			self, 'Brightness',
			'Brightness delta (−255 … +255):\n'
			'Positive = brighter, negative = darker.', 0, -255, 255)
		if ok and delta != 0:
			self.canvas.adjust_brightness(delta)
			self._update_image_stats()

	def _mod_gamma(self):
		gamma, ok = QInputDialog.getDouble(
			self, 'Gamma',
			'Gamma value (0.1 … 5.0).\n'
			'1.0 = no change  |  > 1 brightens midtones  |  < 1 darkens.',
			1.0, 0.1, 5.0, 2)
		if ok and gamma != 1.0:
			self.canvas.adjust_gamma(gamma)
			self._update_image_stats()

	def _mod_contrast(self):
		factor, ok = QInputDialog.getDouble(
			self, 'Contrast',
			'Contrast factor (0.0 … 4.0).\n'
			'1.0 = no change  |  > 1 increases contrast  |  < 1 reduces.',
			1.0, 0.0, 4.0, 2)
		if ok and factor != 1.0:
			self.canvas.adjust_contrast(factor)
			self._update_image_stats()

	def _toggle_ribbon(self):
		self._ribbon_collapsed = not self._ribbon_collapsed
		for tb in self.findChildren(QToolBar):
			if tb.objectName() == 'Ribbon':
				tb.setVisible(not self._ribbon_collapsed)
		tri = '▼' if self._ribbon_collapsed else '▲'
		self._collapse_btn.setText(tri)
		if hasattr(self, '_qa_toggle_btn'):
			self._qa_toggle_btn.setText(tri)
		self._settings.setValue('view/ribbon_collapsed', self._ribbon_collapsed)
		self._settings.sync()

	def _rebuild_swatches(self):
		for i, sw in enumerate(self._swatch_widgets):
			col = PALETTE[i]
			sw._color = QColor(col)
			sw.setStyleSheet(f'background:{col};border:1px solid #888;')
			sw.setToolTip(col)
		# Also update custom row
		for i, sw in enumerate(self._custom_sw):
			col = CUSTOM_PALETTE[i] if i < len(CUSTOM_PALETTE) else ''
			if col:
				sw._color = QColor(col)
				sw.setStyleSheet(f'background:{col};border:1px solid #888;')
			else:
				sw._color = None
				sw.setStyleSheet('background:#e0e0e0;border:1px dashed #aaa;')

	def _rebuild_qa(self):
		self._qa_bar.clear()
		qa_all=[
			('icon_save','Save',self._save),
			('icon_undo','Undo',self.canvas.undo),
			('icon_redo','Redo',self.canvas.redo),
			('icon_print','Print',lambda: None),
			('icon_left_arrow','Previous image',self._prev_img),
			('icon_right_arrow','Next image',self._next_img),
		]
		enabled=self._settings.value('qa/enabled',['icon_save','icon_undo','icon_redo','icon_print'],type=list)
		# Migrate stale settings that predate the icon_ prefix
		enabled = [n if n.startswith('icon_') else f'icon_{n}' for n in enabled]
		for icon_n,label,fn in qa_all:
			if icon_n in enabled:
				act = self._qa_bar.addAction(get_icon(icon_n,16),label,fn)
				act.setToolTip(label)
		self._qa_bar.addSeparator()
		# Customize QA toolbar — hidetools.png icon
		cb=QToolButton(); cb.setIcon(get_icon('icon_hide_toolbar',16)); cb.setAutoRaise(True)
		cb.setToolTip('Customize Quick Access Toolbar')
		cb.setPopupMode(QToolButton.InstantPopup)
		cm=QMenu()
		cm.addAction('Customize Quick Access Toolbar').setEnabled(False)
		cm.addSeparator()
		for icon_n,label,fn in qa_all:
			act=cm.addAction(get_icon(icon_n,16),label)
			act.setCheckable(True); act.setChecked(icon_n in enabled)
			def _toggle(chk, n=icon_n):
				en=self._settings.value('qa/enabled',['icon_save','icon_undo','icon_redo','icon_print'],type=list)
				if chk and n not in en: en.append(n)
				elif not chk and n in en: en.remove(n)
				self._settings.setValue('qa/enabled',en); self._rebuild_qa()
			act.toggled.connect(_toggle)
		cb.setMenu(cm); self._qa_bar.addWidget(cb)
		# Hide/show toolbar — black triangle, right of customize
		self._qa_toggle_btn=QToolButton(); self._qa_toggle_btn.setText('▲')
		self._qa_toggle_btn.setAutoRaise(True)
		self._qa_toggle_btn.setToolTip('Hide/show toolbar')
		self._qa_toggle_btn.clicked.connect(self._toggle_ribbon)
		self._qa_bar.addWidget(self._qa_toggle_btn)

	# ─── Status bar ───────────────────────────────────────────────────────────
	def _build_statusbar(self):
		self._sb = self.statusBar()
		self._sb.setSizeGripEnabled(False)

		# Left: cursor coords
		self._lbl_coords = QLabel(''); self._lbl_coords.setMinimumWidth(80)
		self._sb.addWidget(self._lbl_coords)

		# Pixel color info (shown on shift+click, cleared on move)
		self._lbl_pixel = QLabel(''); self._lbl_pixel.setMinimumWidth(100)
		self._sb.addWidget(self._lbl_pixel)

		# Autosave indicator — clickable to toggle
		self._lbl_autosave = QLabel('Autosave: off')
		self._lbl_autosave.setMinimumWidth(90)
		self._lbl_autosave.setCursor(Qt.PointingHandCursor)
		self._lbl_autosave.setToolTip('Click to toggle autosave')
		self._lbl_autosave.mousePressEvent = lambda e: self._toggle_autosave()
		self._sb.addWidget(self._lbl_autosave)

		# Delete confirm indicator — clickable to toggle
		self._lbl_delconfirm = QLabel('Del without confirm: off')
		self._lbl_delconfirm.setMinimumWidth(220)
		self._lbl_delconfirm.setCursor(Qt.PointingHandCursor)
		self._lbl_delconfirm.setToolTip('Click to toggle Del without confirm')
		self._lbl_delconfirm.mousePressEvent = lambda e: self._toggle_delconfirm()
		self._sb.addWidget(self._lbl_delconfirm)

		# Center: image size
		self._lbl_size = QLabel('')
		self._sb.addPermanentWidget(self._lbl_size, 1)

		# NEW: Unique colour count
		self._lbl_colors = QLabel('Colors: —')
		self._lbl_colors.setMinimumWidth(90)
		self._lbl_colors.setToolTip('Number of unique colours in the image')
		self._sb.addPermanentWidget(self._lbl_colors)

		# NEW: File size on disk (or estimated RAM size when unsaved)
		self._lbl_filesize = QLabel('Size: —')
		self._lbl_filesize.setMinimumWidth(80)
		self._lbl_filesize.setToolTip('File size on disk (estimated when unsaved)')
		self._sb.addPermanentWidget(self._lbl_filesize)

		# Image counter (e.g. 5/20), empty until prev/next used
		self._lbl_imgcount = QLabel('')
		self._lbl_imgcount.setMinimumWidth(60)
		self._sb.addPermanentWidget(self._lbl_imgcount)

		# Zoom lock button — when locked, zoom cannot be changed automatically
		self._zoom_locked = False
		self._btn_zoom_lock = QToolButton()
		self._btn_zoom_lock.setAutoRaise(True)
		self._btn_zoom_lock.setFixedSize(20, 20)
		self._btn_zoom_lock.setCheckable(True)
		self._btn_zoom_lock.setChecked(False)
		self._btn_zoom_lock.setToolTip('Lock zoom (prevent zoom changes)')
		self._btn_zoom_lock.clicked.connect(self._toggle_zoom_lock)
		self._update_zoom_lock_icon()
		self._sb.addPermanentWidget(self._btn_zoom_lock)

		# Zoom out button
		zout = QToolButton(); zout.setIcon(get_icon('icon_zoom_out', 16))
		zout.setAutoRaise(True); zout.setFixedSize(20, 20)
		zout.clicked.connect(lambda: self.canvas.set_zoom(round(max(0.1, self.canvas.zoom - 0.1), 2)))
		self._sb.addPermanentWidget(zout)

		# Zoom slider — center=100%, left=10%, right=1600%, logarithmic
		# slider range 0-200, value 100 = zoom 1.0
		self._zoom_slider = QSlider(Qt.Horizontal)
		self._zoom_slider.setRange(0, 200)
		self._zoom_slider.setSingleStep(1)
		self._zoom_slider.setPageStep(10)
		self._zoom_slider.setValue(100)
		self._zoom_slider.setFixedWidth(120)
		self._zoom_slider.setToolTip('Zoom (center = 100%)')
		self._zoom_slider.valueChanged.connect(self._on_zoom_slider)
		self._sb.addPermanentWidget(self._zoom_slider)

		# Zoom in button
		zin = QToolButton(); zin.setIcon(get_icon('icon_zoom_in', 16))
		zin.setAutoRaise(True); zin.setFixedSize(20, 20)
		zin.clicked.connect(lambda: self.canvas.set_zoom(round(min(16.0, self.canvas.zoom + 0.1), 2)))
		self._sb.addPermanentWidget(zin)

		self._lbl_zoom = QLabel('100%')
		self._lbl_zoom.setMinimumWidth(45)
		self._lbl_zoom.setToolTip('Click: reset to 100%\nCtrl+Click: fit to window\nDouble-click: enter zoom level')
		self._lbl_zoom.setCursor(Qt.PointingHandCursor)
		self._zoom_click_timer = QTimer(); self._zoom_click_timer.setSingleShot(True)
		self._zoom_click_timer.timeout.connect(lambda: self.canvas.set_zoom(1.0))
		def _zoom_label_click(e):
			if e.modifiers() & Qt.ControlModifier:
				self._zoom_click_timer.stop(); self._apply_auto_zoom()
			else:
				self._zoom_click_timer.start(250)   # wait for possible double-click
		def _zoom_label_dblclick(e):
			self._zoom_click_timer.stop()   # cancel single-click action
			val, ok = QInputDialog.getInt(self, 'Zoom', 'Zoom level (%):', int(self.canvas.zoom*100), 1, 1600)
			if ok: self.canvas.set_zoom(val/100.0)
		self._lbl_zoom.mousePressEvent = _zoom_label_click
		self._lbl_zoom.mouseDoubleClickEvent = _zoom_label_dblclick
		self._sb.addPermanentWidget(self._lbl_zoom)

	def _toggle_zoom_lock(self):
		self._zoom_locked = self._btn_zoom_lock.isChecked()
		self._update_zoom_lock_icon()
		self._save_settings()

	def _update_zoom_lock_icon(self):
		"""Draw a simple lock icon inline using a QPixmap."""
		locked = self._zoom_locked
		pm = QPixmap(16, 16); pm.fill(Qt.transparent)
		p = QPainter(pm)
		p.setRenderHint(QPainter.Antialiasing)
		color = QColor('#c0392b') if locked else QColor('#555555')
		p.setPen(QPen(color, 1.5))
		p.setBrush(QBrush(color))
		# Shackle (arc on top)
		shackle_rect = QRect(4, 1, 8, 8)
		if locked:
			p.drawArc(shackle_rect, 0 * 16, 180 * 16)
		else:
			# Open lock: right side of shackle is open/lifted
			p.drawArc(QRect(4, 0, 8, 7), 20 * 16, 140 * 16)
		# Body
		p.setBrush(QBrush(color))
		p.setPen(Qt.NoPen)
		p.drawRoundedRect(2, 7, 12, 8, 2, 2)
		# Keyhole
		p.setBrush(QBrush(QColor('#ffffff') if locked else QColor('#bbbbbb')))
		p.setPen(Qt.NoPen)
		p.drawEllipse(6, 9, 4, 4)
		p.end()
		self._btn_zoom_lock.setIcon(QIcon(pm))
		tip = 'Zoom locked — click to unlock' if locked else 'Lock zoom'
		self._btn_zoom_lock.setToolTip(tip)

	def _toggle_autosave(self):
		new_val = not self.canvas._auto_save_lossless
		self.canvas._auto_save_lossless = new_val
		self._chk_autosave.blockSignals(True)
		self._chk_autosave.setChecked(new_val)
		self._chk_autosave.blockSignals(False)
		self._update_autosave_label()
		self._save_settings()

	def _toggle_delconfirm(self):
		new_val = not self._chk_del_noconfirm.isChecked()
		self._chk_del_noconfirm.blockSignals(True)
		self._chk_del_noconfirm.setChecked(new_val)
		self._chk_del_noconfirm.blockSignals(False)
		self._update_delconfirm_label()
		self._save_settings()

	def _update_delconfirm_label(self):
		no_confirm = self._chk_del_noconfirm.isChecked()
		if no_confirm:
			self._lbl_delconfirm.setText('Del without confirm: <span style="color:red">on</span>')
			self._lbl_delconfirm.setTextFormat(Qt.RichText)
		else:
			self._lbl_delconfirm.setText('Del without confirm: off')
			self._lbl_delconfirm.setTextFormat(Qt.PlainText)

	def _update_autosave_label(self):
		on = self.canvas._auto_save_lossless
		if on:
			self._lbl_autosave.setText('Autosave: <span style="color:red">on</span>')
			self._lbl_autosave.setTextFormat(Qt.RichText)
		else:
			self._lbl_autosave.setText('Autosave: off')
			self._lbl_autosave.setTextFormat(Qt.PlainText)

	def _on_zoom_slider(self, val):
		# slider 0-200, center(100) = zoom 1.0
		# left half 0-100: zoom 0.1 to 1.0 (linear)
		# right half 100-200: zoom 1.0 to 16.0 (linear)
		if val <= 100:
			zoom = 0.1 + (val / 100.0) * 0.9
		else:
			zoom = 1.0 + ((val - 100) / 100.0) * 15.0
		self.canvas.set_zoom(round(max(0.1, min(16.0, zoom)), 2))

	def _update_zoom_slider(self):
		z = self.canvas.zoom
		if z <= 1.0:
			val = int((z - 0.1) / 0.9 * 100)
		else:
			val = int(100 + (z - 1.0) / 15.0 * 100)
		self._zoom_slider.blockSignals(True)
		self._zoom_slider.setValue(max(0, min(200, val)))
		self._zoom_slider.blockSignals(False)

	def _apply_auto_zoom(self):
		if self._zoom_locked:
			self.canvas.set_zoom(self._settings.value('view/zoom_level',1.0,float)); return
		scroll = self.centralWidget()
		if not scroll: return
		# Reserve space for canvas resize handles (8px handle + 4px margin each side)
		handle_margin = self.canvas._HANDLE_SIZE + 8
		vw = max(1, scroll.width()  - handle_margin)
		vh = max(1, scroll.height() - handle_margin)
		iw = self.canvas._image.width()
		ih = self.canvas._image.height()
		if iw <= 0 or ih <= 0: return
		import math
		fit_zoom = min(vw / iw, vh / ih)
		fit_zoom = math.floor(fit_zoom * 100) / 100  # always floor, never round up
		zoom_big   = self._chk_zoom_big.isChecked()
		zoom_small = self._chk_zoom_small.isChecked()
		if fit_zoom < 1.0 and zoom_big:
			self.canvas.set_zoom(fit_zoom)
		elif fit_zoom > 1.0 and zoom_small:
			self.canvas.set_zoom(fit_zoom)
		else:
			self.canvas.set_zoom(1.0)

	def _update_imgcount(self):
		imgs = self._dir_imgs()
		if not imgs or not self.canvas.filename:
			self._lbl_imgcount.setText('')
			return
		cur = Path(self.canvas.filename)
		try: idx = imgs.index(cur)
		except ValueError: self._lbl_imgcount.setText(''); return
		self._lbl_imgcount.setText(f'{idx+1}/{len(imgs)}')

	def _on_cursor(self,x,y):
		self._lbl_coords.setText(f'{x}, {y} px')
		self._lbl_pixel.setText('')   # clear pixel info on any move

	def _on_pixel_picked(self, r, g, b):
		self._lbl_pixel.setText(f'  rgb({r}, {g}, {b})')
	def _on_canvas_color(self,c,is_fg):
		if is_fg: self.canvas.set_fg(c); self._color_disp.set_fg(c)
		else:	 self.canvas.set_bg(c); self._color_disp.set_bg(c)
	def _on_size(self,w,h):
		self._lbl_size.setText(f'{w} x {h} px')
		self._lbl_zoom.setText(f'{int(self.canvas.zoom*100)}%')
		self._update_zoom_slider()
		self._update_image_stats()
	def _on_modified(self,v):
		name=Path(self.canvas.filename).name if self.canvas.filename else 'Untitled'
		self.setWindowTitle(f'{"*" if v else ""}{name} - Clone Paint')
		self._update_imgcount()
	def _toggle_sb(self,v): self._sb.setVisible(v); self._save_settings()

	def _update_image_stats(self):
		"""Refresh Colors and Size labels in the status bar."""
		_, label = self.canvas.color_depth_info()
		self._lbl_colors.setText(f'Colors: {label}')
		# File size
		fn = self.canvas.filename
		if fn and Path(fn).exists():
			sz = Path(fn).stat().st_size
			if sz < 1024:
				self._lbl_filesize.setText(f'Size: {sz} B')
			elif sz < 1024 * 1024:
				self._lbl_filesize.setText(f'Size: {sz/1024:.1f} KB')
			else:
				self._lbl_filesize.setText(f'Size: {sz/1048576:.1f} MB')
		else:
			# Estimate: width × height × 4 bytes (ARGB32) before compression
			est = self.canvas._image.width() * self.canvas._image.height() * 4
			if est < 1024:
				self._lbl_filesize.setText(f'Size: ~{est} B')
			elif est < 1024 * 1024:
				self._lbl_filesize.setText(f'Size: ~{est//1024} KB')
			else:
				self._lbl_filesize.setText(f'Size: ~{est//1048576} MB')

	# ─── Settings ─────────────────────────────────────────────────────────────
	def _save_settings(self):
		s=self._settings
		s.setValue('view/rulers',	self._chk_rulers.isChecked())
		s.setValue('view/gridlines', self._chk_gridlines.isChecked())
		s.setValue('view/statusbar', self._chk_statusbar.isChecked())
		s.setValue('view/transp',	self._chk_transp.isChecked())
		s.setValue('view/autosave',  self._chk_autosave.isChecked())
		s.setValue('view/maxpng',	self._chk_maxpng.isChecked())
		s.setValue('view/zoom_big',  self._chk_zoom_big.isChecked())
		s.setValue('view/zoom_small',self._chk_zoom_small.isChecked())
		s.setValue('view/start_select',   self._chk_start_select.isChecked())
		s.setValue('view/recycle',		 self._chk_recycle.isChecked())
		s.setValue('view/del_noconfirm',   self._chk_del_noconfirm.isChecked())
		s.setValue('view/pinch_stretch',   self._chk_pinch_stretch.isChecked())
		s.setValue('view/beep_screenshot',  self._chk_beep.isChecked())
		s.setValue('view/ribbon_collapsed',self._ribbon_collapsed)
		s.setValue('view/active_tab', self._ribbon_stack.currentIndex())
		s.setValue('view/zoom_locked', self._zoom_locked)
		s.setValue('view/zoom_level',  self.canvas.zoom)
		s.sync()

	def _load_settings(self):
		s=self._settings
		self._load_palette()
		self._rebuild_swatches()
		# Block all signals during load to prevent premature _save_settings calls
		chks = [self._chk_rulers, self._chk_gridlines, self._chk_statusbar,
				self._chk_transp, self._chk_autosave, self._chk_maxpng,
				self._chk_zoom_big, self._chk_zoom_small, self._chk_start_select,
				self._chk_recycle, self._chk_del_noconfirm, self._chk_pinch_stretch,
				self._chk_beep]
		for c in chks: c.blockSignals(True)
		self._chk_rulers.setChecked(   s.value('view/rulers',	False, bool))
		self._chk_gridlines.setChecked(s.value('view/gridlines', False, bool))
		self._chk_statusbar.setChecked(s.value('view/statusbar', True,  bool))
		self._chk_transp.setChecked(   s.value('view/transp',	True,  bool))
		self._chk_autosave.setChecked( s.value('view/autosave',  False, bool))
		self._chk_maxpng.setChecked(   s.value('view/maxpng',	False, bool))
		self._chk_zoom_big.setChecked( s.value('view/zoom_big',  True,  bool))
		self._chk_zoom_small.setChecked(s.value('view/zoom_small',False, bool))
		self._chk_start_select.setChecked(s.value('view/start_select', False, bool))
		self._chk_recycle.setChecked(	  s.value('view/recycle',	  True,  bool))
		self._chk_del_noconfirm.setChecked(s.value('view/del_noconfirm',False, bool))
		self._chk_pinch_stretch.setChecked(s.value('view/pinch_stretch', False, bool))
		self._chk_beep.setChecked(		 s.value('view/beep_screenshot', False, bool))
		for c in chks: c.blockSignals(False)
		self.canvas._show_rulers	   = self._chk_rulers.isChecked()
		self.canvas._show_gridlines	= self._chk_gridlines.isChecked()
		self.canvas.set_show_transparency(self._chk_transp.isChecked())
		self.canvas._auto_save_lossless  = self._chk_autosave.isChecked()
		self.canvas._max_png_compression = self._chk_maxpng.isChecked()
		self.canvas._pinch_stretch	   = self._chk_pinch_stretch.isChecked()
		self._beep_on_screenshot		 = self._chk_beep.isChecked()
		self._sb.setVisible(self._chk_statusbar.isChecked())
		self._update_autosave_label(); self._update_delconfirm_label()
		if self._chk_start_select.isChecked(): self.canvas.set_tool('selectrect')
		else: self.canvas.set_tool('brush')
		active_tab=s.value('view/active_tab',0,int)
		if active_tab==2: self._tab_modify.setChecked(True); self._ribbon_stack.setCurrentIndex(2)
		elif active_tab==1: self._tab_view.setChecked(True); self._ribbon_stack.setCurrentIndex(1)
		else: self._tab_home.setChecked(True); self._ribbon_stack.setCurrentIndex(0)
		if s.value('view/ribbon_collapsed',False,bool): self._toggle_ribbon()
		if s.value('view/zoom_locked',False,bool):
			self._zoom_locked=True; self._btn_zoom_lock.setChecked(True); self._update_zoom_lock_icon()
			self._apply_saved_zoom_on_load=True
			self._saved_zoom_to_apply=s.value('view/zoom_level',1.0,float)
		else:
			self._apply_saved_zoom_on_load=False; self._saved_zoom_to_apply=None

	# ─── Colours ──────────────────────────────────────────────────────────────
	def _choose_fg(self, shift=False):
		if shift:
			c = QColorDialog.getColor(self.canvas._fg, self, 'Color 1')
			if c.isValid():
				self.canvas.set_fg(c); self._color_disp.set_fg(c)
		# else just select Color1 (already done by ColorDisplay click)

	def _choose_bg(self, shift=False):
		if shift:
			c = QColorDialog.getColor(self.canvas._bg, self, 'Color 2')
			if c.isValid():
				self.canvas.set_bg(c); self._color_disp.set_bg(c)
		# else just select Color2 (already done by ColorDisplay click)

	def _on_swatch(self, color, is_left_click):
		# Apply color to whichever of Color1/Color2 is active
		active = self._color_disp.active
		if active == 'fg':
			self.canvas.set_fg(color); self._color_disp.set_fg(color)
		else:
			self.canvas.set_bg(color); self._color_disp.set_bg(color)

	def _edit_colors(self):
		dlg = QDialog(self); dlg.setWindowTitle('Edit Colors')
		lay = QVBoxLayout(dlg)
		cd = QColorDialog(); cd.setOption(QColorDialog.NoButtons, True)
		lay.addWidget(cd)
		lay.addWidget(QLabel('Pick a color above, then click a swatch to assign it:'))

		# 3 rows of swatches: row1+row2 = PALETTE (15 each), row3 = CUSTOM_PALETTE
		grid = QGridLayout(); grid.setSpacing(3)
		sw_list = []
		for i, col in enumerate(PALETTE):
			sw = QPushButton(); sw.setFixedSize(20,20)
			sw.setStyleSheet(f'background:{col};border:1px solid #888;')
			def assign_palette(checked=False, idx=i, btn=sw):
				c = cd.currentColor()
				if c.isValid():
					PALETTE[idx] = c.name()
					btn.setStyleSheet(f'background:{c.name()};border:1px solid #888;')
					self._rebuild_swatches()
			sw.clicked.connect(assign_palette)
			grid.addWidget(sw, i//10, i%10)
			sw_list.append(sw)
		# Row 3 — custom slots
		for i in range(10):
			sw = QPushButton(); sw.setFixedSize(20,20)
			col = CUSTOM_PALETTE[i] if CUSTOM_PALETTE[i] else '#e0e0e0'
			sw.setStyleSheet(f'background:{col};border:1px dashed #aaa;')
			def assign_custom(checked=False, idx=i, btn=sw):
				c = cd.currentColor()
				if c.isValid():
					CUSTOM_PALETTE[idx] = c.name()
					btn.setStyleSheet(f'background:{c.name()};border:1px solid #888;')
					if idx < len(self._custom_sw):
						self._custom_sw[idx].set_color(c)
			sw.clicked.connect(assign_custom)
			grid.addWidget(sw, 2, i)
		lay.addLayout(grid)
		btns = QHBoxLayout()
		ok = QPushButton('OK'); ok.clicked.connect(dlg.accept)
		btns.addWidget(ok); lay.addLayout(btns)
		dlg.exec_()
		self._save_palette()

	# ─── File ops ─────────────────────────────────────────────────────────────
	def _ask_save(self):
		if not self.canvas.modified: return True
		# Honor autosave: if enabled and file is lossless, save silently
		if self.canvas._auto_save_lossless and self.canvas.filename:
			ext = Path(self.canvas.filename).suffix.lower()
			if ext in ('.png', '.bmp'):
				self.canvas.auto_save()
				return True
		name=Path(self.canvas.filename).name if self.canvas.filename else 'Untitled'
		r=QMessageBox.question(self,'Save?',f'Save changes to {name}?',
							   QMessageBox.Yes|QMessageBox.No|QMessageBox.Cancel)
		if r==QMessageBox.Cancel: return False
		if r==QMessageBox.Yes: self._save()
		return True

	def _new(self):
		if not self._ask_save(): return
		# Use current image size, or 400x400 if no image
		w = self.canvas._image.width() if self.canvas._image else 400
		h = self.canvas._image.height() if self.canvas._image else 400
		self.canvas.new_image(w, h)

	def _new_small(self):
		"""Always create a 400×400 px canvas."""
		if not self._ask_save(): return
		self.canvas.new_image(400, 400)

	def _close_image(self):
		"""Close current image — ask to save if modified, then clear and resize to 0 (actually 1,1)."""
		if not self._ask_save(): return
		#self.canvas.new_image(400, 400)
		
		#clear image
		self.canvas._image.fill(Qt.transparent) 
		self.canvas.setFixedSize(0, 0)
		self.canvas._filename = ''
		self.canvas._set_modified(False)

	def _default_dir(self):
		if self.canvas.filename: return str(Path(self.canvas.filename).parent)
		return str(Path(__file__).parent)

	def _open_path(self, path):
		if not self._ask_save(): return
		self.canvas.open_file(path); self._apply_auto_zoom(); self._update_imgcount()

	def _open(self):
		if not self._ask_save(): return
		path,_=QFileDialog.getOpenFileName(self,'Open',self._default_dir(),
			'Image Files (*.png *.jpg *.jpeg *.bmp *.gif *.tif *.tiff *.jxl);;All Files (*.*)')
		if path: self.canvas.open_file(path); self._apply_auto_zoom(); self._update_imgcount()

	def _save(self):
		if not self.canvas.filename: self._save_as()
		else: self.canvas.save_file(self.canvas.filename)

	def _save_as(self):
		path,filt=QFileDialog.getSaveFileName(self,'Save As',self._default_dir(),
			'PNG (*.png);;JPEG (*.jpg);;BMP (*.bmp);;GIF (*.gif);;JPEG XL (*.jxl);;All Files (*.*)')
		if not path: return
		if not Path(path).suffix:
			if 'PNG' in filt: path+='.png'
			elif 'JPEG XL' in filt: path+='.jxl'
			elif 'JPEG' in filt: path+='.jpg'
			elif 'BMP' in filt: path+='.bmp'
			elif 'GIF' in filt: path+='.gif'
			else: path+='.png'
		self.canvas.save_file(path)

	def _save_as_fmt(self,ext):
		path,_=QFileDialog.getSaveFileName(self,f'Save as {ext.upper()}',self._default_dir(),f'{ext.upper()} (*.{ext})')
		if path:
			if not path.lower().endswith('.'+ext): path+='.'+ext
			self.canvas.save_file(path)

	def _paste_from(self):
		path,_=QFileDialog.getOpenFileName(self,'Paste From','',
			'Image Files (*.png *.jpg *.bmp *.gif);;All Files (*.*)')
		if path:
			img=QImage(path)
			if not img.isNull():
				QApplication.clipboard().setImage(img); self.canvas.paste()

	def _screenshot(self):
		"""Wait 2 s, grab all screens, copy to clipboard only (no paste)."""
		QTimer.singleShot(2000, self._do_screenshot_full_nopaste)

	def _do_screenshot_full_nopaste(self):
		try:
			img = self._grab_all_screens()
			if img is None: return
			QApplication.clipboard().setImage(img)
			self._cheese();
		except Exception as e:
			QMessageBox.warning(self, 'Screenshot failed', str(e))

	def _screenshot_active(self):
		"""Wait 2 s, then detect the active window and grab it (no paste).
		The geometry is recorded AFTER the delay so switching windows during
		the countdown picks the correct target."""
		QTimer.singleShot(2000, self._do_screenshot_active_nopaste)

	def _do_screenshot_active_nopaste(self):
		try:
			geom = self._get_active_window_geom()
			pm = self._grab_window_by_geom(geom)
			if pm is None: return
			img = pm.toImage().convertToFormat(QImage.Format_ARGB32)
			QApplication.clipboard().setImage(img)
			self._cheese()
		except Exception as e:
			QMessageBox.warning(self, 'Screenshot failed', str(e))

	def _screenshot_and_paste(self):
		"""Wait 2 s, grab all screens, paste."""
		QTimer.singleShot(2000, self._do_screenshot_full)

	def _do_screenshot_full(self):
		try:
			img = self._grab_all_screens()
			if img is None: return
			QApplication.clipboard().setImage(img)
			self._cheese(); self.canvas.paste()
		except Exception as e:
			QMessageBox.warning(self, 'Screenshot failed', str(e))

	def _screenshot_active_and_paste(self):
		"""Wait 2 s, then detect the active window, grab it and paste.
		Geometry is recorded AFTER the delay so you can switch windows first."""
		QTimer.singleShot(2000, self._do_screenshot_active)

	def _do_screenshot_active(self):
		try:
			geom = self._get_active_window_geom()
			pm = self._grab_window_by_geom(geom)
			if pm is None: return
			img = pm.toImage().convertToFormat(QImage.Format_ARGB32)
			QApplication.clipboard().setImage(img)
			self._cheese(); self.canvas.paste()
		except Exception as e:
			QMessageBox.warning(self, 'Screenshot failed', str(e))

	def _get_active_window_geom(self):
		"""Return (x, y, w, h) of the currently focused window in virtual desktop coords, or None."""
		try:
			import subprocess
			r = subprocess.run(['xdotool', 'getactivewindow'],
							   capture_output=True, text=True, timeout=2)
			if r.returncode == 0:
				wid = r.stdout.strip()
				rg = subprocess.run(['xdotool', 'getwindowgeometry', '--shell', wid],
									capture_output=True, text=True, timeout=2)
				if rg.returncode == 0:
					info = {}
					for line in rg.stdout.splitlines():
						if '=' in line:
							k, v = line.split('=', 1)
							info[k.strip()] = v.strip()
					x = int(info.get('X', 0))
					y = int(info.get('Y', 0))
					w = int(info.get('WIDTH', 0))
					h = int(info.get('HEIGHT', 0))
					if w > 0 and h > 0:
						return (x, y, w, h)
		except Exception:
			pass
		return None

	def _grab_all_screens(self):
		"""Grab all monitors and stitch into one image. Returns QImage or None."""
		screens = QApplication.screens()
		if not screens: return None
		if len(screens) == 1:
			pm = screens[0].grabWindow(0)
			return pm.toImage().convertToFormat(QImage.Format_ARGB32) if not pm.isNull() else None
		# Find bounding rect of all screens in virtual desktop coords
		virt = QRect()
		for s in screens:
			virt = virt.united(s.geometry())
		if virt.isEmpty(): return None
		result = QImage(virt.width(), virt.height(), QImage.Format_ARGB32)
		result.fill(Qt.black)
		p = QPainter(result)
		for s in screens:
			pm = s.grabWindow(0)
			if pm.isNull(): continue
			g = s.geometry()
			# Place each screen at its virtual desktop offset
			p.drawPixmap(g.x() - virt.x(), g.y() - virt.y(), pm)
		p.end()
		return result

	def _grab_window_by_geom(self, geom):
		"""Grab the screen region described by geom (x,y,w,h in virtual coords).
		Returns a QPixmap or None. Falls back to grabbing all screens."""
		screens = QApplication.screens()
		if not screens: return None
		if geom is None:
			# No geometry — grab primary screen
			pm = QApplication.primaryScreen().grabWindow(0)
			return pm if not pm.isNull() else None
		x, y, w, h = geom
		# Find which screen contains the top-left of the window
		target_screen = None
		for s in screens:
			if s.geometry().contains(x, y):
				target_screen = s; break
		if target_screen is None:
			target_screen = QApplication.primaryScreen()
		sg = target_screen.geometry()
		dpr = target_screen.devicePixelRatio()
		# Grab the entire target screen
		full_pm = target_screen.grabWindow(0)
		if full_pm.isNull(): return None
		# Crop: coords relative to screen origin, scaled by DPR
		rx = int((x - sg.x()) * dpr)
		ry = int((y - sg.y()) * dpr)
		rw = int(w * dpr)
		rh = int(h * dpr)
		sw = full_pm.width(); sh = full_pm.height()
		rx = max(0, min(rx, sw - 1))
		ry = max(0, min(ry, sh - 1))
		rw = max(1, min(rw, sw - rx))
		rh = max(1, min(rh, sh - ry))
		cropped = full_pm.copy(rx, ry, rw, rh)
		return cropped if not cropped.isNull() else None

	def _cheese(self):
		"""Flash 'Cheese!' in the status bar and optionally beep."""
		self._lbl_coords.setText('Cheese!')
		if getattr(self, '_beep_on_screenshot', False):
			QApplication.beep()
		QTimer.singleShot(3000, lambda: self._lbl_coords.setText(''))

	def _properties(self):
		w=self.canvas._image.width(); h=self.canvas._image.height()
		QMessageBox.information(self,'Properties',
			f'Image size: {w} × {h} pixels\nFile: {self.canvas.filename or "Untitled"}')

	def _delete_current_file(self):
		"""Delete the currently open file, honoring recycle and confirmation settings."""
		if not self.canvas.filename:
			QMessageBox.information(self, 'Delete', 'No file is currently open.')
			return
		path = self.canvas.filename
		name = Path(path).name
		no_confirm = self._chk_del_noconfirm.isChecked()
		use_recycle = self._chk_recycle.isChecked()
		if not no_confirm:
			dest = 'recycle bin' if use_recycle else 'permanently'
			r = QMessageBox.question(self, 'Delete file',
				f'Delete {name} ({dest})?',
				QMessageBox.Yes | QMessageBox.No)
			if r != QMessageBox.Yes: return
		# Get list and index BEFORE deleting
		imgs_before = self._dir_imgs()
		try: idx = list(imgs_before).index(Path(path))
		except ValueError: idx = 0
		try:
			if use_recycle:
				try:
					import send2trash
					send2trash.send2trash(path)
				except ImportError:
					# Fallback: use gio trash (available on most Linux desktops)
					import subprocess
					result = subprocess.run(['gio', 'trash', path], capture_output=True)
					if result.returncode != 0:
						# Final fallback: move to ~/.local/share/Trash/files/
						trash_dir = Path.home() / '.local' / 'share' / 'Trash' / 'files'
						trash_dir.mkdir(parents=True, exist_ok=True)
						import shutil
						shutil.move(path, str(trash_dir / Path(path).name))
			else:
				os.remove(path)
		except Exception as e:
			QMessageBox.warning(self, 'Delete failed', str(e))
			return
		imgs_after = [p for p in imgs_before if str(p) != path]
		if imgs_after:
			# Open next file, fall back to previous if deleted was last
			next_idx = min(idx, len(imgs_after) - 1)
			self.canvas.open_file(str(imgs_after[next_idx]))
			self._apply_auto_zoom()
			self._update_imgcount()
		else:
			self.canvas.new_image(400, 400)
			self._update_imgcount()

	def _rename_file(self):
		if not self.canvas.filename: return
		old = Path(self.canvas.filename)
		name, ok = QInputDialog.getText(self, 'Rename', 'New filename:', text=old.name)
		if not ok or not name: return
		new = old.parent / name
		if not new.suffix: new = new.with_suffix(old.suffix)
		try:
			old.rename(new)
			self.canvas._filename = str(new)
			self._on_modified(self.canvas.modified)
		except Exception as e:
			QMessageBox.warning(self, 'Rename failed', str(e))

	def _reload_file(self):
		if not self.canvas.filename: return
		if self.canvas.modified:
			r = QMessageBox.question(self, 'Reload', 'Discard changes and reload?',
				QMessageBox.Yes | QMessageBox.No)
			if r != QMessageBox.Yes: return
		self.canvas.open_file(self.canvas.filename)
		self._apply_auto_zoom()

	def _move_file(self):
		if not self.canvas.filename: return
		dst = QFileDialog.getExistingDirectory(self, 'Move to folder',
				str(Path(self.canvas.filename).parent))
		if not dst: return
		self._move_to_dir(dst)

	def _move_to_temp(self):
		if not self.canvas.filename: return
		tmp = Path(self.canvas.filename).parent / 'temp'
		tmp.mkdir(exist_ok=True); self._move_to_dir(str(tmp))

	def _move_to_dir(self, dst):
		import shutil
		src = Path(self.canvas.filename)
		imgs_before = self._dir_imgs()
		try: idx = list(imgs_before).index(src)
		except ValueError: idx = 0
		try: shutil.move(str(src), dst)
		except Exception as e: QMessageBox.warning(self, 'Move failed', str(e)); return
		imgs_after = [p for p in imgs_before if p != src]
		if imgs_after:
			self.canvas.open_file(str(imgs_after[min(idx, len(imgs_after)-1)]))
			self._apply_auto_zoom(); self._update_imgcount()
		else:
			self.canvas.new_image(400, 400); self._update_imgcount()

	def _copy_file(self):
		if not self.canvas.filename: return
		dst = QFileDialog.getExistingDirectory(self, 'Copy to folder',
				str(Path(self.canvas.filename).parent))
		if not dst: return
		self._copy_to_dir(dst)

	def _copy_to_temp(self):
		if not self.canvas.filename: return
		tmp = Path(self.canvas.filename).parent / 'temp'
		tmp.mkdir(exist_ok=True); self._copy_to_dir(str(tmp))

	def _copy_to_dir(self, dst):
		import shutil
		try: shutil.copy2(self.canvas.filename, dst)
		except Exception as e: QMessageBox.warning(self, 'Copy failed', str(e))

	def _first_file(self):
		imgs = self._dir_imgs()
		if imgs and self._ask_save():
			self.canvas.open_file(str(imgs[0]))
			self._apply_auto_zoom(); self._update_imgcount()

	def _last_file(self):
		imgs = self._dir_imgs()
		if imgs and self._ask_save():
			self.canvas.open_file(str(imgs[-1]))
			self._apply_auto_zoom(); self._update_imgcount()

	def _about(self):
		QMessageBox.information(self,'About Clone Paint',
'Clone Paint\nPyQt5 edition\nPaint program with a familiar interface.\n\n'
'Keyboard shortcuts:\n'
'Ctrl+Z / Ctrl+Y: Undo / Redo\n'
'Ctrl+S: Save\n'
'Ctrl+O: Open\n'
'Ctrl+N: New\n'
'Ctrl+A: Select all\n'
'Ctrl+C / X / V: Copy / Cut / Paste\n'
'Ctrl+T: Open Thumbnails window\n'
'Ctrl+scroll: Zoom in / out (10% step)\n'
'Left / Right: Previous / Next image\n'
'Home / End: First / Last file in folder\n'
'F2: Rename file\n'
'F5: Reload file\n'
'F7 / Shift+F7: Move to folder / Move to temp\n'
'F8 / Shift+F8: Copy to folder / Copy to temp\n'
'Delete: Delete selection (if selected)\n'
'Delete: Delete file (if nothing selected)\n'
'Esc: Switch to Rectangular Select\n'
'Ctrl+click 100%: Fit image to window\n'
'Double click 100%: Enter zoom level\n')

	def _rotate_custom(self):
		dlg = QDialog(self); dlg.setWindowTitle('Custom Rotation')
		dlg.setWindowIcon(get_icon('icon_outline'))
		lay = QVBoxLayout(dlg)
		# Angle input
		al = QHBoxLayout()
		al.addWidget(QLabel('Angle (degrees, negative=left):'))
		angle_sp = QDoubleSpinBox(); angle_sp.setRange(-360.0, 360.0)
		angle_sp.setDecimals(2); angle_sp.setValue(0.0)
		al.addWidget(angle_sp); lay.addLayout(al)
		# Antialias checkbox
		aa_chk = QCheckBox('Enable antialiasing'); aa_chk.setChecked(True)
		lay.addWidget(aa_chk)
		# Background color
		bl = QHBoxLayout(); bl.addWidget(QLabel('Background color:'))
		bg_btn = QPushButton(); bg_btn.setFixedSize(40, 20)
		bg_color = [QColor(Qt.white)]
		bg_btn.setStyleSheet('background:white;border:1px solid #888;')
		def pick_bg():
			c = QColorDialog.getColor(bg_color[0], dlg, 'Background color')
			if c.isValid():
				bg_color[0] = c
				bg_btn.setStyleSheet(f'background:{c.name()};border:1px solid #888;')
		bg_btn.clicked.connect(pick_bg)
		bl.addWidget(bg_btn); lay.addLayout(bl)
		# OK/Cancel
		btns = QHBoxLayout()
		ok = QPushButton('OK'); ok.clicked.connect(dlg.accept)
		ca = QPushButton('Cancel'); ca.clicked.connect(dlg.reject)
		btns.addWidget(ok); btns.addWidget(ca); lay.addLayout(btns)
		if dlg.exec_() == QDialog.Accepted:
			deg = angle_sp.value()
			if deg == 0: return
			self.canvas._push_undo()
			cx = self.canvas._image.width() / 2; cy = self.canvas._image.height() / 2
			new_img = QImage(self.canvas._image.size(), QImage.Format_ARGB32)
			new_img.fill(bg_color[0])
			p = QPainter(new_img)
			if aa_chk.isChecked():
				p.setRenderHint(QPainter.Antialiasing)
				p.setRenderHint(QPainter.SmoothPixmapTransform)
			p.translate(cx, cy); p.rotate(deg); p.translate(-cx, -cy)
			p.drawImage(0, 0, self.canvas._image)
			p.end()
			self.canvas._image = new_img
			self.canvas._set_modified(True); self.canvas.update()

	def _resize_dialog(self):
		w=self.canvas._image.width(); h=self.canvas._image.height()
		dlg=QDialog(self); dlg.setWindowTitle('Resize'); dlg.setModal(True)
		lay=QVBoxLayout(dlg)
		grp=QGroupBox('Resize'); gl=QGridLayout(grp)
		gl.addWidget(QLabel('Width:'),0,0)
		ew=QSpinBox(); ew.setRange(1,10000); ew.setValue(w); gl.addWidget(ew,0,1)
		gl.addWidget(QLabel('Height:'),1,0)
		eh=QSpinBox(); eh.setRange(1,10000); eh.setValue(h); gl.addWidget(eh,1,1)
		chk=QCheckBox('Maintain aspect ratio'); chk.setChecked(True); gl.addWidget(chk,2,0,1,2)
		def on_w(): 
			if chk.isChecked(): eh.blockSignals(True); eh.setValue(int(ew.value()*h/max(1,w))); eh.blockSignals(False)
		def on_h():
			if chk.isChecked(): ew.blockSignals(True); ew.setValue(int(eh.value()*w/max(1,h))); ew.blockSignals(False)
		ew.valueChanged.connect(on_w); eh.valueChanged.connect(on_h)
		lay.addWidget(grp)
		btns=QHBoxLayout()
		ok=QPushButton('OK'); ok.clicked.connect(dlg.accept)
		ca=QPushButton('Cancel'); ca.clicked.connect(dlg.reject)
		btns.addWidget(ok); btns.addWidget(ca); lay.addLayout(btns)
		if dlg.exec_()==QDialog.Accepted:
			self.canvas.resize_image(ew.value(),eh.value())

	# ─── Directory navigation ─────────────────────────────────────────────────
	def _dir_imgs(self):
		exts = {'.png','.jpg','.jpeg','.bmp','.gif','.tif','.tiff','.jxl'}
		if self.canvas.filename:
			d = Path(self.canvas.filename).parent
		else:
			d = Path('.')
		return sorted(p for p in d.iterdir() if p.suffix.lower() in exts)

	def _prev_img(self):
		imgs = self._dir_imgs()
		if not imgs: return
		if self.canvas.filename:
			cur = Path(self.canvas.filename)
			try: idx = imgs.index(cur)
			except ValueError: idx = 0
			nxt = imgs[(idx - 1) % len(imgs)]
		else:
			nxt = imgs[-1]
		if self._ask_save():
			self.canvas.open_file(str(nxt))
			self._apply_auto_zoom()
			self._update_imgcount()

	def _next_img(self):
		imgs = self._dir_imgs()
		if not imgs: return
		if self.canvas.filename:
			cur = Path(self.canvas.filename)
			try: idx = imgs.index(cur)
			except ValueError: idx = -1
			nxt = imgs[(idx + 1) % len(imgs)]
		else:
			nxt = imgs[0]
		if self._ask_save():
			self.canvas.open_file(str(nxt))
			self._apply_auto_zoom()
			self._update_imgcount()

	# ─── Keyboard ─────────────────────────────────────────────────────────────
	def keyPressEvent(self,e):
		k=e.key(); m=e.modifiers()
		if m==Qt.ControlModifier:
			if k==Qt.Key_Z: self.canvas.undo()
			elif k==Qt.Key_Y: self.canvas.redo()
			elif k==Qt.Key_S: self._save()
			elif k==Qt.Key_O: self._open()
			elif k==Qt.Key_N: self._new()
			elif k in (Qt.Key_Plus,Qt.Key_Equal): self.canvas.set_zoom(self.canvas.zoom*2)
			elif k==Qt.Key_Minus: self.canvas.set_zoom(self.canvas.zoom/2)
		elif k==Qt.Key_Delete:
			if self.canvas._sel_rect:
				self.canvas.delete_selection()
			elif self.canvas._floating:
				self.canvas._commit_floating()
			else:
				self._delete_current_file()
		elif k==Qt.Key_Left and self.canvas._tool != 'text':
			self._prev_img()
		elif k==Qt.Key_Right and self.canvas._tool != 'text':
			self._next_img()
		elif k==Qt.Key_Home and self.canvas._tool != 'text':
			self._first_file()
		elif k==Qt.Key_End and self.canvas._tool != 'text':
			self._last_file()
		elif k==Qt.Key_F2:  self._rename_file()
		elif k==Qt.Key_F5:  self._reload_file()
		elif k==Qt.Key_F7:
			if m==Qt.ShiftModifier: self._move_to_temp()
			else: self._move_file()
		elif k==Qt.Key_F8:
			if m==Qt.ShiftModifier: self._copy_to_temp()
			else: self._copy_file()
		elif k==Qt.Key_Escape:
			if self.canvas._tool != 'text':
				if self.canvas._tool in ('selectrect','select'):
					self.canvas.set_tool('brush')
				else:
					self.canvas._sel_rect=None; self.canvas._polygon_pts=[]; self.canvas._polygon_phase=0
					self.canvas._sel_free_pts=[]; self.canvas._sel_free_screen=[]
					self.canvas._curve_phase=0; self.canvas.update()
					self.canvas.set_tool('selectrect')
		else: super().keyPressEvent(e)

	# ─── Drag & drop ──────────────────────────────────────────────────────────
	def dragEnterEvent(self,e):
		if e.mimeData().hasUrls(): e.acceptProposedAction()

	def dropEvent(self,e):
		for url in e.mimeData().urls():
			path=url.toLocalFile()
			if path and Path(path).suffix.lower() in ('.png','.jpg','.jpeg','.bmp','.gif','.tif','.tiff','.jxl'):
				if self._ask_save(): self.canvas.open_file(path)
				break

	def closeEvent(self,e):
		if self._ask_save():
			self._settings.setValue('window/geometry', self.saveGeometry())
			self._settings.setValue('window/state',	self.saveState())
			self._save_settings()
			self._save_palette()
			e.accept()
		else: e.ignore()


def main():
	app=QApplication(sys.argv)
	app.setApplicationName('Clone Paint')
	app.setOrganizationName(SETTINGS_ORG)
	open_path=None
	if len(sys.argv)>1 and Path(sys.argv[1]).is_file():
		open_path=sys.argv[1]
	win=MainWindow(open_path)
	sys.exit(app.exec_())

if __name__=='__main__':
	main()
